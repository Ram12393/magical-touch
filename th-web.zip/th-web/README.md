# th-web
Web-facing portal of the platform

#Steps to build and serve
1. Move to root folder of the repository and run `npm install`.
2. Then run `npm run dev`.
3. App should be available in `http://localhost:4200`.