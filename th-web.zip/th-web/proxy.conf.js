const PROXY_CONFIG = {
  "/service/*": {
    "target": "https://services.telehealer.com/",
    "secure": true,
    "pathRewrite": {
      "^/services": ""
    },
    "changeOrigin": true,
    "logLevel": "debug",
  },
  "/api/*": {
    "target": "https://api.dev.telehealer.com/",
    "secure": true,
    "changeOrigin": true,
    "logLevel": "debug"
  },
  "/account/*": {
      "target": "https://api.dev.telehealer.com/",
      "secure": true,
      "pathRewrite": {
          "^/account": ""
      },
      "changeOrigin": true,
      "logLevel": "debug"
  }
}

module.exports = PROXY_CONFIG;