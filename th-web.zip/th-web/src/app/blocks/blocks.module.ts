import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { DirectiveModule } from '../shared/directives/directive.module';

import { ButtonComponent } from './elements/button/button.component';
import { InputComponent } from './elements/input/input.component';
import { InputTypeaheadComponent } from './elements/input-typeahead/input-typeahead.component';
import { TextareaComponent } from './elements/textarea/textarea.component';
import { InputOtpComponent } from './elements/input-otp/input-otp.component';
import { InputDropdownComponent } from './elements/input-dropdown/input-dropdown.component';
import { ThrobberComponent } from './widgets/throbber/throbber.component';
import { InputSearchComponent } from './elements/input-search/input-search.component';
import { AvatarComponent } from './widgets/avatar/avatar.component';
import { FileViewerComponent } from './widgets/file-viewer/file-viewer.component';
import { FileUploaderComponent } from './widgets/file-uploader/file-uploader.component';
import { CheckboxComponent } from './elements/checkbox/checkbox.component';
import { InputCountryComponent } from './elements/input-country/input-country.component';

@NgModule({
  declarations: [
    ButtonComponent,
    InputComponent,
    InputTypeaheadComponent,
    TextareaComponent,
    InputOtpComponent,
    InputDropdownComponent,
    ThrobberComponent,
    InputSearchComponent,
    AvatarComponent,
    FileViewerComponent,
    FileUploaderComponent,
    CheckboxComponent,
    InputCountryComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DirectiveModule,
    NgbModule
  ],
  exports: [
    ButtonComponent,
    InputComponent,
    InputTypeaheadComponent,
    TextareaComponent,
    InputOtpComponent,
    InputDropdownComponent,
    ThrobberComponent,
    InputSearchComponent,
    AvatarComponent,
    FileViewerComponent,
    FileUploaderComponent,
    CheckboxComponent,
    InputCountryComponent
  ]
})
export class BlocksModule {
}
