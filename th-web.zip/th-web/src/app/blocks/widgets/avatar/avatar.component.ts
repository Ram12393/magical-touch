import {Component, OnInit, Input, ViewChild, Output, EventEmitter, ElementRef} from '@angular/core';
import imageCompression from 'browser-image-compression';

import * as $ from 'jquery';

@Component({
    selector: 'app-avatar',
    templateUrl: 'avatar.component.html',
    styleUrls: ['avatar.component.scss']
})
export class AvatarComponent implements OnInit {
    @Input() srcUrl;
    @Input() readonly;
    @Output() set = new EventEmitter();
    @ViewChild("avatarUpload", {static: true}) avatarUpload;
    public src;

    constructor(public ele: ElementRef) {
    }

    ngOnInit() {
        this.src = this.srcUrl || 'assets/images/default_avatar.png';
    }

    onClick() {
        $(this.ele.nativeElement).find("[type='file']").trigger("click");
    }

    uploadAvatar() {
        let fi = this.avatarUpload.nativeElement;
        if (fi.files && fi.files[0]) {
            imageCompression(fi.files[0], {
                    maxSizeMB: 1
                })
                .then((image) => {
                    var reader = new FileReader();
                    reader.readAsDataURL(image);
                    reader.onloadend = () => {
                        this.setAvatar(reader.result);
                    }
                });
        }
    }

    setAvatar(url) {
        this.srcUrl = this.src = url;
        this.set.emit(url);
    };
}