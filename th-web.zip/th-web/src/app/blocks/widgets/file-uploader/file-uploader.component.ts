import {Component, OnInit, Output, EventEmitter, ViewChild, ViewEncapsulation} from '@angular/core';

import imageCompression from 'browser-image-compression';
import * as $ from 'jquery';

import {ToastrService} from "../../../core/services/toastr.service";

@Component({
  selector: 'app-file-uploader',
  templateUrl: 'file-uploader.component.html',
  styleUrls: ['file-uploader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FileUploaderComponent implements OnInit {
  @Output() select = new EventEmitter();
  @ViewChild("input", {static: false}) input;

  constructor(private toastr: ToastrService) { }

  ngOnInit() {
  }

  triggerFileInput(e) {
    $(e.target).closest(".file-uploader-container").find("input").trigger("click");
  }

  selectFile() {
    let files = this.input.nativeElement.files;

    if (files[0] && (files[0].type == "image/png" || files[0].type == "image/jpeg")) {
      imageCompression(files[0], {
            maxSizeMB: 1
          })
          .then((image) => {
            var reader = new FileReader();
            reader.readAsDataURL(image);
            reader.onloadend = () => {
              this.select.emit(reader.result);
            }

          });
    }
    else {
      this.toastr.error("Only JPG and PNG allowed");
    }

    $(this.input.nativeElement).val("");
  }

}
