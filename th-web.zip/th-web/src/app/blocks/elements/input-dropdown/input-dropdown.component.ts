import {Component, OnInit, Input, ElementRef, ViewEncapsulation, OnDestroy, Output, EventEmitter} from '@angular/core';
import { FormControl } from '@angular/forms';

import * as $ from 'jquery';

@Component({
  selector: 'app-input-dropdown',
  templateUrl: 'input-dropdown.component.html',
  styleUrls: ['input-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InputDropdownComponent implements OnInit, OnDestroy {
  @Input() options: any[];
  @Input() inputControl: FormControl;
  @Input() label: string;
  @Input() placeholder: string;
  @Output() change = new EventEmitter();
  public scrollHandler;
  public dropdownTouched: boolean = false;

  constructor(private element: ElementRef) {
    this.scrollHandler = () => {
      $(this.element.nativeElement).find(".input-dropdown-container.show .input-dropdown-label").trigger("click");
    }
  }

  ngOnInit() {
    $(document).on("wheel", this.scrollHandler);
    $(window).on("resize", this.scrollHandler);
    $(this.element.nativeElement).find(".input-dropdown-list-container")
        .width($(this.element.nativeElement).find(".input-dropdown-container").width());
  }

  ngOnDestroy() {
    $(document).off("wheel", this.scrollHandler);
    $(window).off("resize", this.scrollHandler);
  }

}
