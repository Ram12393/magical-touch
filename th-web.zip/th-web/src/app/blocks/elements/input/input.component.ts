import { Component, OnInit, Input, ViewEncapsulation, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';

import * as $ from 'jquery';

@Component({
  selector: 'app-input',
  templateUrl: 'input.component.html',
  styleUrls: ['input.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InputComponent implements OnInit {
  @Input() inputControl: FormControl;
  @Input() label: string;
  @Input() required: boolean;
  @Input() type: string;
  @Input() min: string;
  @Input() max: string;
  @Input() placeholder: string;
  @Input() disabled: boolean;
  @Input() readonly: boolean;
  @Output() appFocus = new EventEmitter();
  @Output() appClick = new EventEmitter();
  @Output() appKeyup = new EventEmitter();
  @Output() appKeydown = new EventEmitter();

  public _componentInstanceId: string;
  public showPassword = false;

  constructor(private ele: ElementRef) {
    this._componentInstanceId = Math.random().toString(36).substring(3);
  }

  ngOnInit() {
    let self = this,
        ele = $(this.ele.nativeElement).find(".input-label-wrapper"),
        input = ele.find("input");


    if (this.inputControl.value != undefined) {
        ele.addClass("active");
    }
    else {
        ele.removeClass("active");
    }

    input.on("focus", function (e) {
          ele.addClass("active");
            self.appFocus.emit(e);
        })
        .on("blur", function () {
            if (self.inputControl.value != undefined) {
              ele.addClass("active");
            }
            else {
              ele.removeClass("active");
            }
        })
        .on("click", function (e) {
            self.appClick.emit(e);
        })
        .on("keyup", function (e) {
            self.appKeyup.emit(e);
        })
        .on("keydown", function (e) {
            self.appKeydown.emit(e);
        });

    self.inputControl.valueChanges.subscribe((value) => {
        if (value != undefined) {
          ele.addClass("active");
        }
        else if (!input.filter(":focus").length) {
          ele.removeClass("active");
        }
    });
  }

}
