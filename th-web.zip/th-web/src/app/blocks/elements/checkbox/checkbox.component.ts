import { Component, OnInit, Input, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CheckboxComponent implements OnInit {
  @Input() inputControl: FormControl;
  @Input() type: string;
  @Input() label: string;
  @Input() id: string;
  constructor() { }

  ngOnInit() {
  }

}
