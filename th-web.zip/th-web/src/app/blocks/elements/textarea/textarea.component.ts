import {Component, OnInit, Input, ElementRef, ViewEncapsulation} from '@angular/core';
import {FormControl} from '@angular/forms';

import * as $ from 'jquery';

@Component({
    selector: 'app-textarea',
    templateUrl: 'textarea.component.html',
    styleUrls: ['textarea.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TextareaComponent implements OnInit {
    @Input() inputControl: FormControl;
    @Input() label: string;
    @Input() required: boolean;

    public _componentInstanceId: string;

    constructor(private ele: ElementRef) {
        this._componentInstanceId = Math.random().toString(36).substring(3);
    }

    ngOnInit() {
        let self = this,
            ele = $(this.ele.nativeElement).find(".textarea-label-wrapper"),
            input = ele.find("textarea:not(.textarea-resize-element)");


        if (this.inputControl.value) {
            ele.addClass("active");
        }
        else {
            ele.removeClass("active");
        }

        input.on("focus", function () {
                ele.addClass("active");
            })
            .on("blur", function () {
                if (self.inputControl.value) {
                    ele.addClass("active");
                }
                else {
                    ele.removeClass("active");
                }
            });

        self.inputControl.valueChanges.subscribe((value) => {
            if (value) {
                ele.addClass("active");
            }
            else if (!input.filter(":focus").length) {
                ele.removeClass("active");
            }
        });

        input.on("keydown", function (e) {
            if (e.keyCode == 13 || e.keyCode == 8) {
                setTimeout(() => {
                    $(this).height($(this).next()[0].scrollHeight);
                });
            }
            else {
                $(this).height($(this).next()[0].scrollHeight);
            }
        });

        setTimeout(() => {
            input.height(input.next()[0].scrollHeight);
        });
    }
}
