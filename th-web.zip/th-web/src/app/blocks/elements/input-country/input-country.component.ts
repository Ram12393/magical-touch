import {Component, OnInit, OnDestroy} from '@angular/core';
import {Store} from "@ngrx/store";
import {SessionUpdate} from "../../../core/store/actions/session.action";
import {GetSession} from "../../../core/store/selectors/session.selector";
import {first} from "rxjs/internal/operators";
import {Session} from "../../../core/store/models/session.model";
import {LoginService} from "../../../modules/login/services/login.service";

@Component({
  selector: 'app-input-country',
  templateUrl: './input-country.component.html',
  styleUrls: ['./input-country.component.scss']
})
export class InputCountryComponent implements OnInit, OnDestroy {
  public country: string;
  public availableCoutries = ["IN", "USA"];
  public loading: boolean = false;
  public countrySubscription$;

  constructor(private store: Store<{}>, private loginService: LoginService) {
    this.countrySubscription$ = this.store.select(GetSession)
        .subscribe((session: Session) => {
          if (session.country) {
            this.country = session.country;
          }
          else {
            this.country = "IN";
            // this.loading = true;
            // this.loginService.getCountryCode({})
            //     .subscribe((response) => {
            //       console.log(response);
            //       this.loading = false;
            //     });
          }
        });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.countrySubscription$.unsubscribe();
  }

  changeFlag(i) {
    this.country = i;
    this.store.dispatch(SessionUpdate({
      country: i
    }));
  }

}
