import {Component, OnInit, Input, Output, ElementRef, EventEmitter, ViewEncapsulation} from '@angular/core';
import {FormControl} from '@angular/forms';

import * as $ from 'jquery';

@Component({
    selector: 'app-input-typeahead',
    templateUrl: 'input-typeahead.component.html',
    styleUrls: ['input-typeahead.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class InputTypeaheadComponent implements OnInit {
    @Input() inputControl: FormControl;
    @Input() typeahead: string[];
    @Input() label: string;
    @Output() onPaginate = new EventEmitter();

    public showtypeahead: boolean = false;

    constructor(private ele: ElementRef) {

    }

    ngOnInit() {
        let ele = $(this.ele.nativeElement).find(".input-typeahead-container"),
            input = ele.find("input");


        input.on("keydown", function (e) {
                if (e.keyCode == 40) {
                    ele.find(".input-typeahead-list-container ul li:first-child")
                        .focus();
                }
                else if (e.keyCode == 38) {
                    ele.find(".input-typeahead-list-container ul li:last-child")
                        .focus();
                }
            })
            .on("focus", () => {
                this.showtypeahead = true;
            });
    }

    setInputControlValue(value) {
        this.showtypeahead = false;
        this.inputControl.setValue(value);
    }

    triggerPagination() {
        this.onPaginate.emit();
    }
}
