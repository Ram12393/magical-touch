import {Component, OnInit, Input, ViewEncapsulation, ElementRef, Output, EventEmitter} from '@angular/core';
import {FormControl} from '@angular/forms';

import * as $ from 'jquery';

@Component({
    selector: 'app-input-otp',
    templateUrl: 'input-otp.component.html',
    styleUrls: ['input-otp.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class InputOtpComponent implements OnInit {
    @Input() digits: number = 0;
    @Output() enter = new EventEmitter();
    @Output() change = new EventEmitter();
    public inputControl: FormControl[] = [];
    public ele;

    constructor(private element: ElementRef) {

    }

    ngOnInit() {
        for (let i = 0; i < this.digits; i++) {
            this.inputControl.push(new FormControl(''));
        }

        this.ele = $(this.element.nativeElement).find(".input-otp-container");
    }

    onClick() {
        for (let i = 0; i < this.digits; i++) {
            if (!this.inputControl[i].value) {
                this.ele.find(".input-otp-wrapper:nth-child(" + (i + 1) + ") input")
                    .focus();
                break;
            }
        }
    }

    onKeyDown(e, i) {
        e.preventDefault();
        if (e.keyCode >= 48 && e.keyCode <= 57) {// from 0 to 9
            this.inputControl[i].setValue(String.fromCharCode(e.keyCode));
            if ($(e.target).closest(".input-otp-wrapper").next().length) {
                $(e.target).closest(".input-otp-wrapper")
                    .next()
                    .find("input")
                    .focus();
            }
            else {
                this.enter.emit(this.inputControl.map(d => d.value).join(''));
            }
            this.change.emit();
        }
        else if (e.keyCode == 8 && i > 0) {// backspace
            if (this.inputControl[i].value) {
                this.inputControl[i].setValue('')
            }
            else {
                this.inputControl[i - 1].setValue('')
                $(e.target).closest(".input-otp-wrapper")
                    .prev()
                    .find("input")
                    .focus();
            }
            this.change.emit();
        }
    }

    clear() {
        for (let i = 0; i < this.digits; i++) {
            this.inputControl[i].setValue('');
        }
    }

}
