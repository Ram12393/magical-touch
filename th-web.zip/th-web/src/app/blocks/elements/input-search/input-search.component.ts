import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Store } from "@ngrx/store";

import { GetSettings } from '../../../core/store/selectors/settings.selector';

@Component({
  selector: 'app-input-search',
  templateUrl: 'input-search.component.html',
  styleUrls: ['input-search.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InputSearchComponent implements OnInit {
  @Input() inputControl: FormControl;
  @Input() label: string;
  settings = {};

  constructor(public store: Store<{}>) {
    this.store.select(GetSettings)
        .subscribe((settings) => {
          this.settings = settings;
        });
  }

  ngOnInit() {
  }

}
