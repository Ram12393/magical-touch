import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {StoreModule} from '@ngrx/store';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';

import {LoginModule} from './modules/login/login.module';
import {RESTFactory} from './core/factory/REST/REST.factory';

import {AppState} from './app.state';
import {DashboardModule} from "./modules/dashboard/dashboard.module";
import { BlocksModule } from './blocks/blocks.module';
import { SharedComponentsModule } from './shared/components/shared-components.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        NgbModule,
        StoreModule.forRoot(AppState),
        LoginModule,
        DashboardModule,
        BlocksModule,
        SharedComponentsModule,
        BrowserAnimationsModule
    ],
    providers: [RESTFactory],
    bootstrap: [AppComponent]
})
export class AppModule {
}
