import { Component, OnDestroy } from '@angular/core';

import { Store } from '@ngrx/store';

import { RESTFactory } from './core/factory/REST/REST.factory';
import { GetSession } from './core/store/selectors/session.selector';
import { GetSettings } from './core/store/selectors/settings.selector';
import { SettingsUpdate } from './core/store/actions/settings.action';
import {Browser} from './core/services/browser.service';
import {SessionUpdate, SessionReset} from './core/store/actions/session.action';
import {AuthService} from './core/services/auth.service';
import {LoginService} from './modules/login/services/login.service';
import {Router, ActivatedRoute} from '@angular/router';
import {map} from 'rxjs/internal/operators';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    public settings = {};
    public createPrescription = false;
    public createRadiology = false;
    public session;

    constructor(
        private restFactory: RESTFactory,
        private store: Store<{}>,
        private Browser: Browser,
        private auth: AuthService,
        public loginService: LoginService,
        private route: Router,
        public activatedRoute: ActivatedRoute) {
        this.storeInit();
        this.appInit();
        this.authenticate();
    }

    ngOnInit() {
    }

    appInit() {
        this.restFactory.config((provider) => {
            provider.setHeader({
                'x-api-key': 'ezuGJrW9O24Ran2gZaF7m2Ro13RTvD1q26IKTj4m'
            });
        });

        this.store.select(GetSession)
            .subscribe((session) => {
                const headers = {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                };

                if (session.token) {
                    headers['X-Access-Token'] = session.token;
                }

                if (session.country) {
                    headers['X-Install-Type'] = session.country === 'IN' ? 'telehealer-india' : 'telehealer';
                }

                this.restFactory.config((provider) => {
                    provider.setHeader(headers);
                });

                this.Browser.storage.set('session', session);

                this.session = session;
            });

        this.store.select(GetSettings)
            .subscribe((settings) => {
                this.settings = settings;
            });
    }

    storeInit() {
        this.store.dispatch(SettingsUpdate({view: 'DOCTOR'}));
        this.store.dispatch(SessionUpdate(this.Browser.storage.get('session') || {}));
    }

    authenticate() {
        this.auth.isAuthenticated()
            .subscribe((isAuthenticated: boolean) => {
                if (isAuthenticated) {
                    this.auth.validateSession()
                        .subscribe(() => {

                            },
                            () => {
                                this.store.dispatch(SessionReset({}));
                                this.route.navigate(['/login']);
                            });
                }
            });
    }

    showMenu() {
        const obs = this.activatedRoute.firstChild || this.activatedRoute;

        return obs.data
            .pipe(
                map((d) => {
                    return !d.hideMenu;
                }));
    }

    create() {
        this.createPrescription = true;
    }
}
