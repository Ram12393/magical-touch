import {AbstractControl, Validators} from "@angular/forms";

export function PatternValidator(pattern, msg) {
    return function (control: AbstractControl) {
        return Validators.pattern(pattern)(control) ? {custom: msg} : null;
    }
}