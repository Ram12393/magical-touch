import {AbstractControl} from "@angular/forms";
import {RegexConstants} from "../../core/config/regex";

export function PasswordValidator(control: AbstractControl) {
    let value = control.value;

    if (value) {
        if (value.length < 8 || value.length > 20) {
            return {custom: "Password length should be 8 to 20"};
        }
        else if (!value.match(RegexConstants.upperCase)) {
            return {custom: "Password must contain atleast 1 upper case character"};
        }
        else if (!value.match(RegexConstants.lowerCase)) {
            return {custom: "Password must contain atleast 1 lower case character"};
        }
        else if (!value.match(RegexConstants.specialCharacter)) {
            return {custom: "Password must contain atleast 1 special character"};
        }
    }

    return null;
}