import {AbstractControl} from "@angular/forms";
import {HttpParams} from "@angular/common/http";

import {map} from "rxjs/internal/operators";
import {HttpParameterCodec} from "@angular/common/http";

export function EmailAvailabilityValidator(loginService, validatorHandler) {
    return (control: AbstractControl) => {
        let a = new HttpParams({encoder: new CustomEncoder()}).set('email', control.value);
        return loginService.checkAvailability({
                params: a
            })
            .pipe(
                map(validatorHandler)
            );
    }
}

class CustomEncoder implements HttpParameterCodec {
    encodeKey(key: string): string {
        return encodeURIComponent(key);
    }

    encodeValue(value: string): string {
        return encodeURIComponent(value);
    }

    decodeKey(key: string): string {
        return decodeURIComponent(key);
    }

    decodeValue(value: string): string {
        return decodeURIComponent(value);
    }
}