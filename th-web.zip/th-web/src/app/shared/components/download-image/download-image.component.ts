import { Component, OnInit, Input } from '@angular/core';
import { PatientService } from '../../../core/services/patient.service';

@Component({
  selector: 'app-download-image',
  templateUrl: 'download-image.component.html',
  styleUrls: ['download-image.component.scss']
})
export class DownloadImageComponent implements OnInit {

  @Input() imgPath: string;
  @Input() classList: string;
  constructor(private patientService:PatientService) { }
  ngOnInit() {
    console.log(this.classList)
  }
}
