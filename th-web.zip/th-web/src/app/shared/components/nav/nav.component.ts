import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { GetSettings } from '../../../core/store/selectors/settings.selector';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { LoginService } from 'src/app/modules/login/services/login.service';
import { SessionReset } from 'src/app/core/store/actions/session.action';

@Component({
  selector: 'app-nav',
  templateUrl: 'nav.component.html',
  styleUrls: ['nav.component.scss']
})
export class NavComponent implements OnInit {
  public displaySub = false;
  public displayMonitoringSub = false;
  public settings = {};
  public tab: string;
  public loading: boolean;
  @Output() addprescription = new EventEmitter();
  @Output() addradiology = new EventEmitter();

  constructor(
    private store: Store<{}>,
    private router: Router,
    public patientService: PatientService,
    public loginService: LoginService) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }

  ngOnInit() {
  }
  openSubmenu(e) {
    e.preventDefault();
    this.displaySub = !this.displaySub;
  }
  openMonitoringSubmenu(e, tabName) {
    e.preventDefault();
    this.tab = tabName;
    this.displayMonitoringSub = !this.displayMonitoringSub;
  }
  CreatePres(e) {
    e.preventDefault();
    this.displaySub = false;
    this.addprescription.emit();
  }
  CreateRadio(e) {
    e.preventDefault();
    this.displaySub = false;
    this.addradiology.emit();
  }
  vitals() {
    this.displayMonitoringSub = !this.displayMonitoringSub;
    this.patientService.getVitalInfo({ params: { filter: 'last_week' } }).subscribe(res => {
      this.router.navigate(['monitoring']);
    });
  }
  logout() {
    // this.displaySub = false;
    this.loading = true;
    this.loginService.logout().subscribe(res => {
      this.store.dispatch(SessionReset({}));
      localStorage.removeItem('store');
      this.loading = false;
      this.router.navigate(['login']);
    });
  }
}


