import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { PatientService } from '../../../core/services/patient.service';
import {FormValidationErrorMessages} from "../../../core/config/form-validation-error-messages";
import {RegexConstants} from "../../../core/config/regex";
import {PatternValidator} from "../../validators/pattern.validator";

@Component({
  selector: 'app-create-prescription',
  templateUrl: 'create-prescription.component.html',
  styleUrls: ['create-prescription.component.scss']
})
export class CreatePrescriptionComponent implements OnInit {
  public patientList: boolean = false;
  public visitPrescription: boolean = false;
  public prescriptionPharmacy: boolean = false;
  public patientinfo:any;
  public visitDateTime:any;
  public saveFaxData:any;
  public successOrder: boolean = false;
  public availableForms:any = ["Tablet","Capsule","Drops","Suppository","Ointment","Injection","Inhaler","Cream","Lozenge","Syrup","Powder","Spray","Gel","Lotion","MouthWash","Shampoo","Solution","Suspension","Sachet"];
  public availableMetric:any = ["mg","mcg","gm"];
  public availabledirection_one:any = ["PO","PR","PC","SQ","Inhalation"];
  public availabledirection_two:any = ["QD","BID","TID","QID","QHS","QAC","PRN","QOD"];
  public prescriptionForm: FormGroup;
  @Output() close = new EventEmitter();
  public pharmacy_dropdown_visibility: boolean = false;
  public successLoading: boolean = false;
  constructor(private fb: FormBuilder, private patientService:PatientService) { }

  ngOnInit() {
    this.prescriptionForm = this.fb.group({
      rx_drug_name: ["", [Validators.required]],
      rx_form: [this.availableForms[0], [Validators.required]],
      rx_strength: [0, [Validators.required, PatternValidator(RegexConstants.number,FormValidationErrorMessages.number)]],
      rx_metric: [this.availableMetric[0], [Validators.required]],
      directions_quantity: [0, [Validators.required, PatternValidator(RegexConstants.number,FormValidationErrorMessages.number) ]],
      directions_select_one: [this.availabledirection_one[0], [Validators.required]],
      directions_select_two: [this.availabledirection_two[0], [Validators.required]],
      dispense_quantity: [0, [Validators.required, PatternValidator(RegexConstants.number,FormValidationErrorMessages.number)]],
      refill_quantity: [0, [Validators.required, PatternValidator(RegexConstants.number,FormValidationErrorMessages.number)]],
      do_not_substitute: [""],
      label:[""]
    });
  }
  saveprescription() {
    this.successLoading = true;
    this.patientService.savePrescription({},this.saveObject())
    .subscribe((result) => {
      if(result.success) {
        this.successOrder = true;
        this.successLoading = false;
      }
    });
  }
  saveandfax() {
    this.prescriptionPharmacy = true;
    this.saveFaxData = this.saveObject();
  }
  saveObject() {
    return {
      "order_id": this.visitDateTime == undefined?"":this.visitDateTime.order_id,
      "name": "Prescription Referral",
      "user_guid": this.patientinfo == undefined?"":this.patientinfo.user_guid,
      "detail": this.prescriptionForm.value
    }
  }
  patientData(value) {
    this.patientinfo = value;
    this.patientList = false;
  }
  visitData(value) {
    this.visitDateTime = value;
    this.visitPrescription = false;
  }
  closepanel() {
    this.close.emit();
  }
}
