import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitPrescriptionComponent } from './visit-prescription.component';

describe('VisitPrescriptionComponent', () => {
  let component: VisitPrescriptionComponent;
  let fixture: ComponentFixture<VisitPrescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisitPrescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisitPrescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
