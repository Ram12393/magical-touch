import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PatientService } from '../../../../core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from '../../../../core/store/selectors/settings.selector';
import { Router } from '@angular/router';

@Component({
  selector: 'app-visit-prescription',
  templateUrl: 'visit-prescription.component.html',
  styleUrls: ['visit-prescription.component.scss']
})
export class VisitPrescriptionComponent implements OnInit {
  public profilesRequestConfig: any;
  public settings = {};
  public visit_data: any;
  public loading: boolean = false;
  @Output() associate_dateTime = new EventEmitter();
  @Output() back_arrow = new EventEmitter();
  constructor(private patientService: PatientService, private route: Router, private store: Store<{}>) {
    this.resetProfilesRequestConfig();
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }

  ngOnInit() {
    let guid = this.route.url.split("/")[this.route.url.split("/").length - 2];
    let parameter;
    if (this.settings["view"] == "DOCTOR") {
      parameter = {
        params: {
          calls: true,
          page: 1,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true,
          user_guid: guid
        }
      }
    } else {
      parameter = {
        params: {
          calls: true,
          page: 1,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true,
          doctor_guid: guid.split("&")[1],
          user_guid: guid.split("&")[0]
        }
      }
    }
    this.loading = true;
    this.patientService.getVisitData(parameter).subscribe(res => {
      this.createGroup(res.result);
    });
  }
  createGroup(visitJson: any) {
    const groups = visitJson.reduce((groups, game) => {
      const date = game.created_at.split('T')[0];
      if (game.durationInSecs > 0) {
        if (!groups[date]) {
          groups[date] = [];
        }
        groups[date].push(game);
      }
      return groups;
    }, {});
    this.visit_data = Object.keys(groups).map((date) => {
      return {
        date,
        visit: groups[date]
      };
    });
    this.loading = false;
  }
  passData(val: any,event:any) {
    let radios = event.currentTarget.parentElement.parentElement.getElementsByTagName("input");
    for(let i=0; i<radios.length; i++) {
      if(radios[i].getAttribute("checked") == "true") {
        radios[i].removeAttribute("checked");
      }
    }
    event.currentTarget.getElementsByTagName("input")[0].setAttribute("checked",true);
    this.associate_dateTime.emit(val);
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }

}
