import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PatientService } from '../../../../core/services/patient.service';
import {FormControl} from "@angular/forms";

@Component({
  selector: 'app-patient-list',
  templateUrl: 'patient-list.component.html',
  styleUrls: ['patient-list.component.scss']
})
export class PatientListComponent implements OnInit {
  public profilesRequestConfig: any;
  public patientList: any[] = [];
  public loading: boolean = false;
  public search = new FormControl('');
  @Output() patientInfo = new EventEmitter();
  @Output() back_arrow = new EventEmitter();
  constructor(private patientService:PatientService) { 
    this.resetProfilesRequestConfig();
  }

  ngOnInit() {
    this.getPatientProfiles();
  }
  getPatientProfiles() {
    this.loading = true;
    this.patientService.getPatientList({
      params: {
        page: ++this.profilesRequestConfig.page,
        page_size: this.profilesRequestConfig.page_size,
        paginate: true
      }
    })
      .subscribe((result) => {
      this.patientList.push.apply(this.patientList,result.result)  
      this.loading = false;
      });
  }
  emitInfo(data:any) {
    this.patientInfo.emit(data);
  }
  resetProfilesRequestConfig() {
    this.patientList = [];
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
}
