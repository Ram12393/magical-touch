import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrescriptionPharmacyComponent } from './prescription-pharmacy.component';

describe('PrescriptionPharmacyComponent', () => {
  let component: PrescriptionPharmacyComponent;
  let fixture: ComponentFixture<PrescriptionPharmacyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrescriptionPharmacyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrescriptionPharmacyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
