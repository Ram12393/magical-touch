import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { PatientService } from '../../../../core/services/patient.service';

@Component({
  selector: 'app-prescription-pharmacy',
  templateUrl: 'prescription-pharmacy.component.html',
  styleUrls: ['prescription-pharmacy.component.scss']
})
export class PrescriptionPharmacyComponent implements OnInit {
  public profilesRequestConfig: any;
  public pharmacyList:any;
  public parameter:any;
  public loading: boolean = false;
  public disablebtn: boolean = true;
  public successOrder: boolean = false;
  public successLoading: boolean = false;
  public currentFaxDetails:any;
  @Input() formData:any;
  @Output() back_arrow = new EventEmitter;
  @Output() closePanel = new EventEmitter;
  constructor(private patientService:PatientService) { 
    this.resetProfilesRequestConfig();
  }


  ngOnInit() {
    this.loading = true;
    this.getpharmacyList("");
  }
  search(value: string) {
    if(value.length >= 3) {
      this.loading = true;
      this.parameter = {
        params: {
          search: value
      }
    }
    this.getpharmacyList(this.parameter);
  }
  }
  getpharmacyList(param) {
    this.patientService.getPharmacy(param)
    .subscribe(data=>{
      this.pharmacyList = data.results;
      this.loading = false;
    });
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
  getDetails(pharmacyInfo) {
    let obj = {
      "detail": {
        "pharmacy": pharmacyInfo
      },
      "referral_id": "1342",
      "fax_number": pharmacyInfo.fax
    }
    this.currentFaxDetails = obj;
    this.disablebtn = false;
  }
  fax() {
    this.successLoading = true;
    this.patientService.savePrescription({},this.formData)
    .subscribe((res)=>{
      if(res.success) {
        this.patientService.sendfax({},this.currentFaxDetails)
      .subscribe((val)=>{
        if(val.success) {
          this.successLoading = false;
          this.successOrder = true;
        }
      })
      }
    })
  }
}
