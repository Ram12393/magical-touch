import { Component, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { FormControl, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { SettingsUpdate } from '../../../core/store/actions/settings.action';

interface Filter {
  filter: string;
  start_date: string;
  filter_type: string;
}

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

  public filterObj;
  public start_date;
  public end_date;
  public showDates = false;
  public DateMessage;
  public monthNames =
    ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  public maxDate: object;
  public minDate: object;
  public model: NgbDateStruct;
  public selectedFilter;
  @Output() close = new EventEmitter();

  constructor(
    private store: Store<{}>,
  ) {
    this.store.select(GetSettings)
      .subscribe((settings: Filter) => {
        console.log(settings.filter_type);
        if (settings.filter_type) {
          this.selectedFilter = settings.filter_type['filter'];
          return;
        }
        this.selectedFilter = 'Last Week';
      });
  }

  ngOnInit() {
    this.initDateControls();
    this.todayDate();
    const currentMonth = new Date().getMonth();
    this.filterObj = {
      last_week: 'Last Week',
      current_month: this.monthNames[currentMonth],
      last_month: this.monthNames[currentMonth - 1],
      custom_range: 'Custom Range'
    };
  }
  filter(el) {
    if(el.filter !== 'Custom Range'){
      this.store.dispatch(SettingsUpdate({ filter_type: el }));
    }
    if (el.filter === 'Custom Range') {
      this.showDates = !this.showDates;
      return;
    }
    const date = new Date();
    if (el.filter === this.filterObj.current_month) {
      const startDate = new Date(date.getFullYear(), date.getMonth(), 1).toLocaleDateString();
      const endDate = new Date().toLocaleDateString();
      this.store.dispatch(SettingsUpdate({ start_date: startDate, end_date: endDate }));
      this.close.emit({ start_date: startDate, end_date: endDate });
      return;
    }
    if (el.filter === this.filterObj.last_month) {
      const startDate = new Date(date.getFullYear() -
        (date.getMonth() > 0 ? 0 : 1), (date.getMonth() - 1 + 12) % 12, 1).toLocaleDateString();
      const endDate = new Date(date.getFullYear(), date.getMonth(), 0).toLocaleDateString();
      this.store.dispatch(SettingsUpdate({ start_date: startDate, end_date: endDate }));
      this.close.emit({ start_date: startDate, end_date: endDate });
      return;
    }

    // this.store.dispatch(SettingsUpdate({ filter: el.filter }));
    this.close.emit(el);
  }
  back() {
    this.showDates = !this.showDates;

  }
  isValid() {
    return this.start_date.valid && this.end_date.valid;
  }

  dateComparision(start_date, end_date) {
    if (new Date(`${end_date}`) > new Date(`${start_date}`)) {
      return true;
    }
    this.DateMessage = 'Start Date should be greater than End Date';
    return false;
  }
  customDateRange() {
    const startDate = `${this.start_date.value.year}-${this.start_date.value.month}-${this.start_date.value.day}`;
    const endDate = `${this.end_date.value.year}-${this.end_date.value.month}-${this.end_date.value.day}`;
    if (this.dateComparision(startDate, endDate)) {
      this.store.dispatch(SettingsUpdate({ filter_type: 'Custom Range' }));
      this.store.dispatch(SettingsUpdate({ start_date: startDate, end_date: endDate }));
      this.close.emit({ start_date: startDate, end_date: endDate });
    }
  }

  initDateControls() {
    this.start_date = new FormControl('', [Validators.required]);
    this.end_date = new FormControl('', [Validators.required]);
  }

  todayDate() {
    const current = new Date();
    this.maxDate = {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate()
    };
  }

  getStartDate() {
    this.minDate = this.start_date.value;
  }
}
