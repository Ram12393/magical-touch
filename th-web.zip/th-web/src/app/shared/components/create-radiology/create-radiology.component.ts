import { Component, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { PatientService } from '../../../core/services/patient.service';

@Component({
  selector: 'app-create-radiology',
  templateUrl: 'create-radiology.component.html',
  styleUrls: ['create-radiology.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CreateRadiologyComponent implements OnInit {
  public patientList: boolean = false;
  public visitPrescription: boolean = false;
  public prescriptionPharmacy: boolean = false;
  public icCodes: boolean = false;
  public patientinfo:any;
  public visitDateTime:any;
  public radiologyData:any;
  public icdData:any;
  public saveFaxData:any;
  public successOrder: boolean = false;
  public radiologyForm: FormGroup;
  @Output() close = new EventEmitter();
  public pharmacy_dropdown_visibility: boolean = false;
  public successLoading: boolean = false;
  public daterequestedMin = new Date();
  public daterequestedMax = new Date(new Date().setFullYear(new Date().getFullYear() + 1));
  constructor(private fb: FormBuilder, private patientService:PatientService) { }

  ngOnInit() {
    this.radiologyForm = this.fb.group({
      comments: ["", [Validators.required]],
      daterequested:["", [Validators.required]]
    });
  }
  saveprescription() {
    this.successLoading = true;
    this.patientService.savePrescription({},this.saveObject())
    .subscribe((result) => {
      if(result.success) {
        this.successOrder = true;
        this.successLoading = false;
      }
    });
  }
  saveandfax() {
    this.prescriptionPharmacy = true;
    this.saveFaxData = this.saveObject();
  }
  saveObject() {
    return {
      "order_id": this.visitDateTime == undefined?"":this.visitDateTime.order_id,
      "name": "Prescription Referral",
      "user_guid": this.patientinfo == undefined?"":this.patientinfo.user_guid,
      "detail": this.radiologyForm.value
    }
  }
  patientData(value) {
    this.patientinfo = value;
    this.patientList = false;
  }
  visitData(value) {
    this.visitDateTime = value;
    this.visitPrescription = false;
  }
  closepanel() {
    this.close.emit();
  }
}
