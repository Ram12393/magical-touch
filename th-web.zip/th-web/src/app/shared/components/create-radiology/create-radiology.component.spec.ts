import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateRadiologyComponent } from './create-radiology.component';

describe('CreateRadiologyComponent', () => {
  let component: CreateRadiologyComponent;
  let fixture: ComponentFixture<CreateRadiologyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateRadiologyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateRadiologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
