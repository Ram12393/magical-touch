import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcCodesComponent } from './ic-codes.component';

describe('IcCodesComponent', () => {
  let component: IcCodesComponent;
  let fixture: ComponentFixture<IcCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
