import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PatientService } from '../../../../core/services/patient.service';

@Component({
  selector: 'app-ic-codes',
  templateUrl: 'ic-codes.component.html',
  styleUrls: ['ic-codes.component.scss']
})
export class IcCodesComponent implements OnInit {
  public icdInfo: any;
  public loading: boolean = false;
  public icdData:any;
  @Output() back_arrow = new EventEmitter;
  constructor(private patientService: PatientService) {
   }

  ngOnInit() {
    this.loading = true;
    this.getIcCodesList("");
  }
  search(value: string) {
    let parameter;
    if(value.length >= 3) {
      this.loading = true;
      parameter = {
        params: {
          search: value
      }
    }
    this.getIcCodesList(parameter);
  }
  }
  getIcCodesList(params) {
    this.patientService.icdCodes(params)
    .subscribe((result) => {
    this.icdData = result.results;
    this.loading = false;
    });
  }
  emitInfo(data:any) {
    this.icdInfo.emit(data);
  }
}
