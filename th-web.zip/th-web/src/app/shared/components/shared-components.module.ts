import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NavComponent } from './nav/nav.component';
import { DownloadImageComponent } from './download-image/download-image.component';
import { CreatePrescriptionComponent } from './create-prescription/create-prescription.component';
import { BlocksModule } from '../../blocks/blocks.module';
import { PrescriptionPharmacyComponent } from './create-prescription/prescription-pharmacy/prescription-pharmacy.component';
import { VisitPrescriptionComponent } from './create-prescription/visit-prescription/visit-prescription.component';
import { PatientListComponent } from './create-prescription/patient-list/patient-list.component';
import { CreateRadiologyComponent } from './create-radiology/create-radiology.component';
import { IcCodesComponent } from './create-radiology/ic-codes/ic-codes.component';
import { DirectiveModule } from '../directives/directive.module';
import { PipeModule } from '../pipes/pipe.module';
import { FilterComponent } from './filter/filter.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    NavComponent,
    DownloadImageComponent,
    CreatePrescriptionComponent,
    PrescriptionPharmacyComponent,
    VisitPrescriptionComponent,
    PatientListComponent,
    CreateRadiologyComponent,
    IcCodesComponent,
    FilterComponent
  ],
  imports: [
    CommonModule,
    BlocksModule,
    DirectiveModule,
    FormsModule,
    ReactiveFormsModule,
    PipeModule,
    NgbModule,

  ],
  exports: [
    NavComponent,
    DownloadImageComponent,
    CreatePrescriptionComponent,
    PrescriptionPharmacyComponent,
    VisitPrescriptionComponent,
    PatientListComponent,
    CreateRadiologyComponent,
    IcCodesComponent,
    FilterComponent
  ]
})
export class SharedComponentsModule { }
