import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FilterPipe } from './filter/filter.pipe';
import { SecondsToHoursMinutesPipe } from './time/seconds-to-hours-minutes.pipe';

@NgModule({
  declarations: [
    FilterPipe,
    SecondsToHoursMinutesPipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    FilterPipe,
    SecondsToHoursMinutesPipe
  ]
})
export class PipeModule { }
