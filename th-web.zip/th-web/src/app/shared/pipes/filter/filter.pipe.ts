import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'filter'
})
export class FilterPipe implements PipeTransform {

    transform(value: any, search: any): any {
        return value.filter((d) => {
            if (typeof search === 'string') {
                if (typeof d === 'object' && this.recursiveSearch(d, search)) {
                    return true;
                } else if (typeof d === 'string') {
                    return d.toLowerCase().indexOf(search.toLowerCase()) > -1;
                }

                return false;
            } else if (typeof search === 'object') {
                return this.recursiveSearch(d, search);
            }
        });
    }

    recursiveSearch(obj: any, search: any) {
        if (typeof search === 'string') {
            for (const i in obj) {
                if (obj.hasOwnProperty(i)) {
                    switch (typeof obj[i]) {
                        case 'string':
                        case 'number':
                            if (String(obj[i]).toLowerCase().indexOf(String(search).toLowerCase()) > -1) {
                                return true;
                            }
                            break;
                        case 'object':
                            if (this.recursiveSearch(obj[i], search)) {
                                return true;
                            }
                            break;
                    }
                }
            }
        } else if (typeof search === 'object') {
            for (const i in search) {
                if (search.hasOwnProperty(i)) {
                    switch (typeof search[i]) {
                        case 'string':
                        case 'number':
                            if ((typeof obj[i] === 'string' || typeof obj[i] === 'number') && String(obj[i]).toLowerCase().indexOf(String(search[i]).toLowerCase()) > -1) {
                                return true;
                            }
                            break;
                        case 'object':
                            if (obj[i] && this.recursiveSearch(obj[i], search[i])) {
                                return true;
                            }
                            break;
                    }
                }
            }


            return false;
        }

    }
}
