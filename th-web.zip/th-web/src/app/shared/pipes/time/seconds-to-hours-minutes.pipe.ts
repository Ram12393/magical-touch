import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'secondsToHoursMinutes'
})
export class SecondsToHoursMinutesPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    const minutes: number = Math.floor(value / 60);
    if (value === 0) {
      return `0 sec`
    }
    return minutes.toString().padStart(2, '0') + `min`+  ':' +
      (value - minutes * 60).toString().padStart(2, '0')+`sec`;
  }

}
