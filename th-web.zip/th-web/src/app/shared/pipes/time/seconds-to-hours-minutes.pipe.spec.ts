import { SecondsToHoursMinutesPipe } from './seconds-to-hours-minutes.pipe';

describe('SecondsToHoursMinutesPipe', () => {
  it('create an instance', () => {
    const pipe = new SecondsToHoursMinutesPipe();
    expect(pipe).toBeTruthy();
  });
});
