import { ScrollEventsDirective } from './scroll-events.directive';

describe('OnScrollEndsDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollEventsDirective();
    expect(directive).toBeTruthy();
  });
});
