import { Directive, Output, ElementRef, EventEmitter } from '@angular/core';

import * as $ from 'jquery';

@Directive({
  selector: '[scroll-events]'
})
export class ScrollEventsDirective {
  @Output() onEnd = new EventEmitter();

  constructor(private ele: ElementRef) { }

  ngOnInit() {
      let self = this;

    $(this.ele.nativeElement).on("scroll", function () {
        if ($(this).height() + $(this).scrollTop() > $(this)[0].scrollHeight - 10) {
            self.onEnd.emit();
        }
    });
  }

}
