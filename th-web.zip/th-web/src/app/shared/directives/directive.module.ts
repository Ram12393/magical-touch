import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {ScrollEventsDirective} from './scroll-events/scroll-events.directive';

@NgModule({
  declarations: [ScrollEventsDirective],
  imports: [
    CommonModule
  ],
  exports: [ScrollEventsDirective]
})
export class DirectiveModule { }
