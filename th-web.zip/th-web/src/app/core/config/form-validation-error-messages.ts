export const FormValidationErrorMessages = {
    alphabet: "Only alphabets are allowed",
    mobile: "Invalid Phone Number",
    number: "Only numeric digits are allowed",
    url: "Invalid URL",
    date: "Invalid Date",
    email: "Invalid Email address",
    alphanumeric: "Only alphanumeric characters are allowed",
    indiaPin: "Invalid pincode",
    usPin: "Invalid zipcode",
};