import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private subject = new Subject<any>();
  list$: Observable<any> = this.subject.asObservable();

  constructor() { }

  sendPatientID(id: string) {
    this.subject.next(id);
  }
  getPatientID(): Observable<any> {
    return this.subject.asObservable();
  }

}
