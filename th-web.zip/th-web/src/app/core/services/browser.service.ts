import { Injectable } from '@angular/core';

import * as $ from 'jquery';

@Injectable({
    providedIn: 'root'
})
export class Browser {
    public cookie;
    public storage;

    constructor() {
        this.storage = new Storage();
    }
}

class Storage {
    private localStorage = window.localStorage;
    private store;

    constructor() {
        if (this.localStorage.getItem("store")) {
            this.store = JSON.parse(this.localStorage.getItem("store"));
        }
        else {
            this.store = {};
        }
    }

    set(key, value) {
        if (this.store[key] && typeof this.store[key] == "object" && typeof value == "object") {
            this.store[key] = $.extend(true, this.store[key], value);
        }
        else {
            this.store[key] = value;
        }

        this.sync();
    }

    get(key) {
        return this.store[key];
    }

    private sync() {
        this.localStorage.setItem("store", JSON.stringify(this.store));
    }

    clear(key) {
        if (key) {
            delete this.store[key];
        }
        else {
            this.store = {};
        }

        this.sync();
    }
}