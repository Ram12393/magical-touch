import { Injectable } from '@angular/core';
import { UrlService } from '../../core/services/url.service';
import { RESTFactory } from '../../core/factory/REST/REST.factory';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  public getPatientList;
  public getPatientInfo;
  public getVitalInfo;
  public getVisitData;
  public getorder_prescription;
  public getorder_labs;
  public getorder_referrals;
  public getorder_radiology;
  public getorder_misc;
  public getorder_fomrs;
  public disconnet_patient;
  public download_image;
  public getPharmacy;
  public savePrescription;
  public sendfax;
  public icdCodes;
  public patientVitals;
  public patientVitalsDetails;
  public download_pdf
    constructor(private restFactory: RESTFactory) {
    this.getPatientList = this.restFactory.for({url: UrlService.DASHBOARD_DATA, method: 'GET'}, {});
    this.getPatientInfo = this.restFactory.for({url: UrlService.DASHBOARD_DATA, method: 'GET'}, {});
    this.getVitalInfo = this.restFactory.for({url: UrlService.VITAL_INFO, method: 'GET'}, {});
    this.getVisitData = this.restFactory.for({url: UrlService.VISIT, method: 'GET'}, {});
    this.getorder_prescription = this.restFactory.for({url: UrlService.ORDER_PRESCRIPTION, method: 'GET'}, {});
    this.getorder_labs = this.restFactory.for({url: UrlService.ORDER_LABS, method: 'GET'}, {});
    this.getorder_referrals = this.restFactory.for({url: UrlService.ORDER_REFERRALS, method: 'GET'}, {});
    this.getorder_radiology = this.restFactory.for({url: UrlService.ORDER_RADIOLOGY, method: 'GET'}, {});
    this.getorder_misc = this.restFactory.for({url: UrlService.ORDER_MISC, method: 'GET'}, {});
    this.getorder_fomrs = this.restFactory.for({url: UrlService.ORDER_FORM, method: 'GET'}, {});
    this.disconnet_patient = this.restFactory.for({url: UrlService.DISCONNECT, method: 'DELETE'}, {});
    this.download_image = this.restFactory.for({url: UrlService.DOWNLOAD_IMAGE, method: 'GET'}, {responseType: 'blob' as 'json'});
    this.getPharmacy = this.restFactory.for({url: UrlService.PHARMACY, method: 'GET'}, {});
    this.savePrescription = this.restFactory.for({url: UrlService.SAVE_RADOLOGY, method: 'POST'}, {});
    this.sendfax = this.restFactory.for({url: UrlService.FAX, method: 'POST'}, {});
    this.icdCodes = this.restFactory.for({url: UrlService.ICDCODES, method: 'GET'}, {});
    this.patientVitals = this.restFactory.for({url: UrlService.PATIENT_VITALS, method: 'GET'}, {});
    this.download_pdf = this.restFactory.for({url: UrlService.DOWNLOAD_PDF, method: 'GET'}, {});

  }
}
