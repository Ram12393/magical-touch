import { environment } from '../../../environments/environment';

class UrlServiceClass {
  /*
   *  Login
   */
  public LOGIN: string = environment.accountEndpoint + "login";
  public RESET_PASSWORD = environment.accountEndpoint + "reset-password";
  public GET_COUNTRY_CODE = "http://ipinfo.io";
  public WHO_AM_I = environment.apiEndpoint + "whoami";
  public LOGOUT = environment.apiEndpoint + 'logout';

  /*
   *  Registration
   */
  public GENERATE_OTP = environment.accountEndpoint + "otp";
  public CHECK_OTP = environment.accountEndpoint + "otp/validate";
  public CHECK_AVAILABILITY = environment.accountEndpoint + "users/check";
  public CREATE_USER: string = environment.accountEndpoint + "setup";
  public UPDATE_USER: string = environment.apiEndpoint + "users/profile";
  public RESEND_EMAIL_VERIFICATION_LINK = environment.apiEndpoint + "setup/verification-link";

  /*
   *  Doctor
   */
  public DOCTOR_REGISTRY: string = environment.servicesEndpoint + "doctors";
  public ALL_DOCTORS: string = environment.apiEndpoint + "associations";

  /*
   * Dashboard-list
   */
  public DASHBOARD_DATA: string = environment.apiEndpoint + "associations";
  public VITAL_INFO: string = environment.apiEndpoint + "vitals";
  public VISIT: string = environment.apiEndpoint + "correspondence-history";
  public ORDER_PRESCRIPTION: string = environment.apiEndpoint + "referrals/prescriptions";
  public ORDER_LABS: string = environment.apiEndpoint + "referrals/labs";
  public ORDER_REFERRALS: string = environment.apiEndpoint + "referrals/specialists";
  public ORDER_RADIOLOGY: string = environment.apiEndpoint + "referrals/x-rays";
  public ORDER_MISC: string = environment.apiEndpoint + "referrals/miscellaneous";
  public ORDER_FORM: string = environment.apiEndpoint + "forms";
  public DISCONNECT: string = environment.apiEndpoint + "associations";
  public DOWNLOAD_IMAGE:string = environment.apiEndpoint + "download";
  public DOWNLOAD_PDF:string = environment.apiEndpoint + "vitals";
  public PHARMACY: string = environment.servicesEndpoint + "pharmacies";
  public SAVE_RADOLOGY: string = environment.apiEndpoint + "referrals/prescriptions";
  public FAX: string = environment.apiEndpoint + "faxes";
  public ICDCODES: string = environment.servicesEndpoint + "icd-codes";
  public PATIENT_VITALS: string = environment.apiEndpoint + 'vitals/users';
  constructor() {
  }
}

export var UrlService = new UrlServiceClass();
