import { Injectable } from '@angular/core';
import {Observable} from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class ToastrService {
    constructor() {
    }

    error(msg, option?) {
        alert(msg);
    }

    success(msg, option?) {
        alert(msg);
    }

    confirm(msg, option?:ConfirmOption) {
        return new Observable((subcriber) => {
            subcriber.next(confirm(msg + (option.primaryButton || '') + "?" ));
            subcriber.complete();
        });
    }
}

type ConfirmOption =  {
    primaryButton?: string,
    secondButton?: string
};