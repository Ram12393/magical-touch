import {Injectable} from '@angular/core';
import {Router} from "@angular/router";

import {JwtHelperService} from '@auth0/angular-jwt';
import {Store} from "@ngrx/store";
import {GetSession} from "../store/selectors/session.selector";
import {first, map} from "rxjs/internal/operators";
import {SessionReset, SessionUpdate} from "../store/actions/session.action";
import {LoginService} from "../../modules/login/services/login.service";
import {SettingsUpdate} from "../store/actions/settings.action";
import {RegistrationDataUpdate} from "../../modules/login/store/actions/registration.actions";

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private jwtHelper = new JwtHelperService();

    constructor(private route: Router, private store: Store<{}>, private loginService: LoginService) {
    }

    isAuthenticated() {
        return this.store.select(GetSession)
            .pipe(
                first(),
                map(session => {
                    if (!session.token || this.jwtHelper.isTokenExpired(session.token)) {
                        this.route.navigate(['/login']);
                        this.store.dispatch(SessionReset({}));
                        return false;
                    }
                    else {
                        return true;
                    }
                }));
    }

    getAuthenticationExpiration() {
        return this.store.select(GetSession)
            .pipe(
                first(),
                map(session => {
                    return this.jwtHelper.getTokenExpirationDate(session.token);
                }));
    }

    validateSession(route?) {
        return this.loginService.whoAmI({})
            .pipe(
                map((data: any) => {
                    this.store.dispatch(SettingsUpdate({"view": data.role == "USER" ? "PATIENT" : "DOCTOR"}));

                    this.store.dispatch(SessionUpdate({
                        country: data.install_type == "telehealer-india" ? "IN" : "USA"
                    }));


                    if (data.status == "ACTIVATION_PENDING" || data.status == "PROFILE_INCOMPLETE") {
                        this.store.dispatch(RegistrationDataUpdate({
                            user_guid: data.user_guid,
                            status: data.status,
                            config: {
                                type: data.role == "USER" ? "PATIENT" : "DOCTOR",
                                role: (function () {
                                    switch (data.role) {
                                        case "USER":
                                            return "PATIENT";
                                        case "BUSER":
                                            return "DOCTOR/EXTENDER";
                                        case "medical_assistant":
                                            return "OFFICE ASSISTANT"
                                    }
                                })()
                            },
                            credentials: {
                                email: data.email,
                                phone: data.phone.slice(3),
                                country_code: data.install_type == "telehealer-india" ? "+91" : "+1"
                            },
                            country_code: data.install_type == "telehealer-india" ? "+91" : "+1"
                        }));

                        this.route.navigate(["/registration"]);
                    }
                    else if (!data.email_verified) {
                        this.store.dispatch(RegistrationDataUpdate({
                            user_guid: data.user_guid,
                            status: "EMAIL_NOT_VERIFIED",
                            config: {
                                type: data.role == "USER" ? "PATIENT" : "DOCTOR",
                                role: (function () {
                                    switch (data.role) {
                                        case "USER":
                                            return "PATIENT";
                                        case "BUSER":
                                            return "DOCTOR/EXTENDER";
                                        case "medical_assistant":
                                            return "OFFICE ASSISTANT"
                                    }
                                })()
                            },
                            credentials: {
                                email: data.email
                            },
                        }));

                        this.route.navigate(["/registration"]);
                    }
                    else if (data.status == "ONBOARDING_PENDING") {
                        this.route.navigate(["/onboarding"]);
                    }
                    else if (route) {
                        this.route.navigate([route]);
                    }
                }));
    }
}