import { Injectable } from '@angular/core';

import { UrlService } from './url.service';
import { RESTFactory } from '../factory/REST/REST.factory';

@Injectable({
    providedIn: 'root'
})
export class DoctorService {
    public getDoctor;
    public getDoctorDetails;
    public createUser;
    public updateProfile;
    public getDoctorList;

    constructor(private restFactory: RESTFactory) {
        this.getDoctor = this.restFactory.for({url: UrlService.DOCTOR_REGISTRY, method: "GET"}, {});
        this.getDoctorDetails = this.restFactory.for({url: UrlService.DOCTOR_REGISTRY, method: "GET"}, {params: {'fields': 'npi,licenses,specialties,practices,educations,hospital_affiliations,profile,uid'}});
        this.createUser = this.restFactory.for({url: UrlService.CREATE_USER, method: "POST"}, {});
        this.updateProfile = this.restFactory.for({url: UrlService.UPDATE_USER, method: "PUT"}, {});
        this.getDoctorList = this.restFactory.for({url: UrlService.ALL_DOCTORS, method: "GET"}, {});
    }
}
