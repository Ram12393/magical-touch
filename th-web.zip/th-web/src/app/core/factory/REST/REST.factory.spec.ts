import { TestBed } from '@angular/core/testing';

import { RESTFactory } from './REST.factory';

describe('ResourceFactoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RESTFactory = TestBed.get(RESTFactory);
    expect(service).toBeTruthy();
  });
});
