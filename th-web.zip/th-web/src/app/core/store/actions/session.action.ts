import { createAction, props } from '@ngrx/store';

import { Session } from '../models/session.model';

export const SessionUpdate = createAction(
    '[Signin Component] update session',
    props<Session>()
);

export const SessionReset = createAction(
    '[Signin Component] reset session',
    props<{}>()
);
