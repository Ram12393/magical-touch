import { createAction, props } from '@ngrx/store';

export const SettingsUpdate = createAction(
    '[App Component] settings update',
    props<{}>()
);
