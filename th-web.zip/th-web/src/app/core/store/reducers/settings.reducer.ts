import { createReducer, on, Action } from '@ngrx/store';

import { SettingsUpdate } from '../actions/settings.action';

const settings: {} = {};

const SettingsReducerFactory = createReducer(
    settings,
    on(SettingsUpdate, (state, prop) => {
        let payload = {...prop};

        delete payload.type;

        return ({...state, ...payload});
    })
);

export function SettingsReducer(state: {} = {}, action: Action) {
    return SettingsReducerFactory(state, action);
}