import { createReducer, on, Action } from '@ngrx/store';

import { Session } from '../models/session.model';
import { SessionUpdate } from '../actions/session.action';

const initialSession: Session = {
    token: null,
    country: ''
};

const SessionReducerFactory = createReducer(
    initialSession,
    on(SessionUpdate, (state, prop) => {
        let propCopy = {...prop};

        delete propCopy.type;

        return ({...state, ...propCopy});
    })
);

export function SessionReducer(state: Session = initialSession, action: Action) {
    return SessionReducerFactory(state, action);
}