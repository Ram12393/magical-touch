export type Session = {
    token?: string,
    country?: string
}