import { Session } from './session.model';
import { LoginState } from '../../../modules/login/store/models/login-state.model';

export interface AppState {
    session: Session;
    settings: {};
    login: LoginState;
}
