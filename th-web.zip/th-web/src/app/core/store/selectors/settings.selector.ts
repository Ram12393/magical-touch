import {AppState} from "../models/appState.model";

export const GetSettings = (state: AppState) => {
    return state.settings;
};