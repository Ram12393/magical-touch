import { AppState } from '../models/appState.model';

export const GetSession = (state: AppState) => {
    return state.session;
};