import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import { Router } from '@angular/router';

import { Store } from "@ngrx/store";

import { LoginService } from '../../services/login.service';
import { SessionUpdate } from '../../../../core/store/actions/session.action';
import { GetSettings } from '../../../../core/store/selectors/settings.selector';

@Component({
    selector: 'app-signin',
    templateUrl: 'signin.component.html',
    styleUrls: ['signin.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class SigninComponent implements OnInit {
    public model;
    public settings = {};

    constructor(private loginService: LoginService, private store: Store<{}>, private router:Router) {

        this.model = {
            'email': new FormControl('', [Validators.email, Validators.required]),
            'password': new FormControl('', [Validators.required])
        };

        this.store.select(GetSettings)
            .subscribe((settings) => {
                this.settings = settings;
            });
    }

    ngOnInit() {
    }

    isValid() {
        return this.model.email.valid && this.model.password.valid;
    }

    onLogin() {
        this.loginService.login({}, {
                "email": this.model.email.value,
                "password": this.model.password.value
            })
            .subscribe((data) => {
                this.store.dispatch(SessionUpdate({
                    token: data.token
                }));
                localStorage.setItem("token",data.token);
                this.router.navigate(['patients']);
            });
    }

}