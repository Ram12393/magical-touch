import {Component, OnInit, OnDestroy} from '@angular/core';
import {Store} from "@ngrx/store";
import {GetSettings} from "../../../../core/store/selectors/settings.selector";
import {LoginService} from "../../services/login.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-onboarding',
  templateUrl: './onboarding.component.html',
  styleUrls: ['./onboarding.component.scss']
})
export class OnboardingComponent implements OnInit, OnDestroy {
  private settingsSubscription$;
  public settings;
  public user = {};
  public loading: boolean = false;

  constructor(private store: Store<{}>,  private loginService: LoginService, private router: Router) {
    this.settingsSubscription$ = this.store.select(GetSettings)
        .subscribe((settings) => {
          this.settings =  settings;
        });
  }

  ngOnInit() {
    this.loading = true;
    this.loginService.whoAmI({})
        .subscribe((user) => {
                if (user.status == "ONBOARDING_PENDING") {
                    this.user = user;
                }
                else {
                    this.router.navigate(["/patients"]);
                }
              this.loading = false;
            },
            () => {
                this.router.navigate(["/login"]);
            });
  }

  ngOnDestroy() {
    this.settingsSubscription$.unsubscribe();
  }

}
