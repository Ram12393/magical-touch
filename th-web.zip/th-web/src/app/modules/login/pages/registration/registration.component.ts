import {Component, OnInit, ViewEncapsulation, OnDestroy} from '@angular/core';

import { Store } from "@ngrx/store";
import { first } from "rxjs/internal/operators";

import {ToastrService} from '../../../../core/services/toastr.service';

import {
    GetRegistrationData, GetPracticeList, GetConfig, GetInsuranceType, GetStatus
} from "../../store/selectors/registration.selector";
import {RegistrationHelperService} from "../../services/registration-helper.service";
import {GetSettings} from "../../../../core/store/selectors/settings.selector";


@Component({
    selector: 'app-registration',
    templateUrl: 'registration.component.html',
    styleUrls: ['registration.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class RegistrationComponent implements OnInit, OnDestroy {
    public currentRegistrationStep: number;
    public totalRegistraionStepsDoctor: number;
    public totalRegistraionStepsAssistant: number;
    public role;
    public type;
    public settings;
    private configSubscription$;

    constructor(private registrationPayloadService: RegistrationHelperService, private toastr: ToastrService, private store: Store<{}>) {
        this.totalRegistraionStepsDoctor = 14;
        this.totalRegistraionStepsAssistant = 11;
        this.currentRegistrationStep = 1;

        this.role = '';
        this.type = "";


        this.configSubscription$ = this.store.select(GetConfig)
            .subscribe((config) => {
                if (config) {
                    this.role = config.role;
                    this.type = config.type
                }
            });

        this.store.select(GetSettings)
            .subscribe((settings) => {
                this.settings = settings;
            });

        /*
         *  Resume registration
         */
        this.store.select(GetRegistrationData)
            .pipe(first())
            .subscribe((data) => {
                if (data.status == "ACTIVATION_PENDING") {
                    this.currentRegistrationStep = 6;
                    this.registrationPayloadService.updateUserProfile();
                }
                else if (data.status == "PROFILE_INCOMPLETE") {
                    if (data.config.role == "PATIENT" || data.config.role == "OFFICE ASSISTANT") {
                        this.currentRegistrationStep = 7;
                    }
                    else if (data.config.role == "DOCTOR/EXTENDER") {
                        if (data.credentials.country_code == "+91") {
                            this.currentRegistrationStep = 10;
                            this.registrationPayloadService.updateUserProfile();
                        }
                        else {
                            this.currentRegistrationStep = 7;
                        }
                    }
                }
                else if (data.status == "EMAIL_NOT_VERIFIED") {
                    if (data.config.role == "PATIENT") {
                        this.currentRegistrationStep = 11;
                    }
                    else if (data.config.role == "OFFICE ASSISTANT") {
                        this.currentRegistrationStep = 10;
                    }
                    else if (data.config.role == "DOCTOR/EXTENDER") {
                        this.currentRegistrationStep = 14;
                    }
                }
            });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.configSubscription$.unsubscribe();
    }

    onNext() {
        if (this.currentRegistrationStep <= 6) {
            switch (this.currentRegistrationStep) {
                case 6:
                    this.store.select(GetRegistrationData)
                        .pipe(first())
                        .subscribe(data => {
                            if (data.credentials.country_code == "+1" && data.config.role == 'DOCTOR/EXTENDER') {
                                this.currentRegistrationStep++;
                            }
                            else if (data.credentials.country_code == "+91" && data.config.role == 'DOCTOR/EXTENDER') {
                                this.currentRegistrationStep = 10;
                                this.registrationPayloadService.updateUserProfile();
                            }
                            else {
                                this.currentRegistrationStep++;
                                this.registrationPayloadService.updateUserProfile();
                            }
                        });
                    break;
                default:
                    this.currentRegistrationStep++;
                    break;
            }
        }
        else {
            if (this.role == 'DOCTOR/EXTENDER') {
                if (this.currentRegistrationStep <= this.totalRegistraionStepsDoctor) {
                    switch (this.currentRegistrationStep) {
                        case 8:
                            this.store.select(GetPracticeList)
                                .pipe(first())
                                .subscribe(list => {
                                    if (list && list.length) {
                                        this.currentRegistrationStep = 9;
                                    }
                                    else {
                                        this.currentRegistrationStep = 10;
                                    }
                                });
                            break;
                        default:
                            this.currentRegistrationStep++;
                            break;
                    }
                }
            }
            else {
                if (this.currentRegistrationStep <= this.totalRegistraionStepsAssistant) {
                    if (this.role != 'PATIENT') {
                        this.currentRegistrationStep++;
                    }
                    else {
                        switch (this.currentRegistrationStep) {
                            case 9:
                                this.store.select(GetInsuranceType)
                                    .pipe(first())
                                    .subscribe(type => {
                                        if (type == "INSURANCE") {
                                            this.currentRegistrationStep++;
                                        }
                                        else {
                                            this.currentRegistrationStep = 11;
                                        }
                                    });
                                break;
                            default:
                                this.currentRegistrationStep++;
                                break;
                        }
                    }
                }
            }
        }
    }

    onPrev() {
        if (this.currentRegistrationStep > 1) {
            switch (this.currentRegistrationStep) {
                case 10:
                    this.store.select(GetRegistrationData)
                        .pipe(first())
                        .subscribe(data => {
                            if (this.role != 'DOCTOR/EXTENDER') {
                                this.currentRegistrationStep--;
                            }
                            else if (data.practiceList && data.practiceList.length && data.credentials.country_code == "+1") {
                                this.currentRegistrationStep = 9;
                            }
                            else if (data.credentials.country_code == "+1") {
                                this.currentRegistrationStep = 8;
                            }
                        });
                    break;
                default:
                    this.currentRegistrationStep--;
                    break;
            }
        }
    }

    skipProfileSelection() {
        this.currentRegistrationStep = 10;
    }
}
