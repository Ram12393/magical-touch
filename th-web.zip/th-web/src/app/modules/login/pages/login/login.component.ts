import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Store } from "@ngrx/store";

import { GetSettings } from '../../../../core/store/selectors/settings.selector';

@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit {
  public settings = {};

  constructor(private store: Store<{}>) {
    this.store.select(GetSettings)
        .subscribe((settings) => {
          this.settings = settings;
        });
  }

  ngOnInit() {
  }

}
