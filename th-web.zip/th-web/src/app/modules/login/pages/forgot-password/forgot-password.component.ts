import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { Store } from "@ngrx/store";

import { GetSettings } from "../../../../core/store/selectors/settings.selector";
import {AppState} from "../../../../core/store/models/appState.model";

@Component({
  selector: 'app-forgot-password',
  templateUrl: 'forgot-password.component.html',
  styleUrls: ['forgot-password.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ForgotPasswordComponent implements OnInit {
  public settings;
  public currentStep = 1;

  constructor(public store: Store<AppState>) {
    this.store.select(GetSettings)
        .subscribe((settings) => {
          this.settings = settings;
        });
  }

  ngOnInit() {
  }

  onNext() {
    this.currentStep++;
  }

  onPrev() {
    this.currentStep--;
  }

  retry() {
    this.currentStep = 3;
  }
}
