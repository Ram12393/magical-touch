import {Injectable} from '@angular/core';

import {Store} from "@ngrx/store";
import {map, first, mergeMap} from "rxjs/internal/operators";

import * as $ from 'jquery';

import {GetRegistrationData, GetConfig} from "../store/selectors/registration.selector";
import {DoctorDetail} from "../store/models/registration.data";
import {RegistrationDataUpdate} from "../store/actions/registration.actions";
import {Config} from "../store/models/registration.model";
import {DoctorService} from "../../../core/services/doctor.service";
import {SessionUpdate} from "../../../core/store/actions/session.action";
import {Observable} from "rxjs";
import {ToastrService} from "../../../core/services/toastr.service";

@Injectable({
    providedIn: 'root'
})
export class RegistrationHelperService {

    constructor(private store: Store<{}>, private doctorService: DoctorService, private toastr: ToastrService) {
    }

    updateUserProfile(detail: any = DoctorDetail) {
        this.store.select(GetConfig)
            .pipe(first())
            .subscribe((config: Config) => {
                if (config.type == "DOCTOR" && config.role == "DOCTOR/EXTENDER") {
                    let doctorDetials = {
                        "first_name": detail.profile.first_name || '',
                        "last_name": detail.profile.last_name || '',
                        "title": detail.profile.title || '',
                        "speciality": '',
                        "bio": detail.profile.bio || '',
                        "gender": detail.profile.gender || '',
                        "website": '',
                        "landline": '',
                        "official_phone": '',
                        "fax": '',
                        "liability_insurance_name": '',
                        "registration_number": '',
                        "year_of_registration": '',
                        "state_medical_council_for_mci": '',
                        "licenses": [],
                        "npi": detail.npi || ''
                    };

                    if (detail.speciality || detail.specialties.length) {
                        doctorDetials.speciality = detail.specialties[0].name;
                    }

                    if (detail.licenses.length) {
                        detail.licenses.forEach((d) => {
                            doctorDetials.licenses.push({
                                "state_mo": d.state || '',
                                "no": d.number || '',
                                "expiry_date": ''
                            });
                        });
                    }

                    this.store.dispatch(RegistrationDataUpdate({
                        doctor_details: doctorDetials,
                        practice: {
                            "clinic_name": '',
                            "street": '',
                            "suite": '',
                            "city": '',
                            "state": '',
                            "pin": ''
                        },
                        practiceList: detail.practices.length ? detail.practices : '',
                        user_avatar: detail.profile.image_url
                    }));
                }
                else if (config.type == "DOCTOR" && config.role == "OFFICE ASSISTANT") {
                    this.store.dispatch(RegistrationDataUpdate({
                        medical_assistant_details: {
                            "first_name": '',
                            "last_name": '',
                            "title": '',
                            "degree": '',
                            "gender": ''
                        }
                    }));
                }
                else {
                    this.store.dispatch(RegistrationDataUpdate({
                        patient_details: {
                            "first_name": '',
                            "last_name": '',
                            "dob": '',
                            "gender": ''
                        }
                    }));
                }
            });
    }

    dataURLtoFile(dataurl) {
        if (!dataurl) {
            return undefined;
        }

        var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while(n--){
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new File([u8arr], '', {type:mime});
    }

    getUserSetupPayload(role) {
        return this.store.select(GetRegistrationData)
            .pipe(
                map((data: any) => {
                    let payload = {
                        email: data.credentials.email,
                        phone: data.credentials.country_code + data.credentials.phone,
                        role: role
                    };

                    if (role == "BUSER") {
                        payload = Object.assign(payload, {"appt_length": 30, "appt_start_time": "08:00 AM", "appt_end_time": "09:30 PM"});
                    }

                    return payload;
                }));
    }

    getDoctorPayload() {
        return this.store.select(GetRegistrationData)
            .pipe(
                map((data: any) => {
                    let payload: any = {
                        user_data: {
                            first_name: data.doctor_details.first_name,
                            last_name: data.doctor_details.last_name,
                            title: data.doctor_details.title,
                            speciality: data.doctor_details.speciality,
                            bio: data.doctor_details.bio,
                            gender: data.doctor_details.gender,
                            website: data.doctor_details.website,
                            landline: data.doctor_details.landline,
                            official_phone: data.doctor_details.official_phone,
                            fax: data.doctor_details.official_phone,
                            role: "BUSER"
                        },
                        user_avatar: data.user_avatar.indexOf("data:image/png;base64") > -1 ? this.dataURLtoFile(data.user_avatar) : null,
                        user_detail: {},
                        certificates: {
                            driver_license: this.dataURLtoFile(data.certificates.driver_license),
                            diploma_certificate: this.dataURLtoFile(data.certificates.diploma_certificate)
                        }
                    };

                    if (data.signature) {
                        payload.signature = this.dataURLtoFile(data.signature);
                    }

                    if (data.credentials.country_code == "+1") {
                        payload.user_detail = {
                            clinic: data.practice,
                            license: data.doctor_details.licenses.map((d) => {
                                var license = {};
                                for (let i in d) {
                                    license[i] = d[i];
                                }

                                return license;
                            }),
                            npi: data.doctor_details.npi,
                            liability_insurance_name: data.doctor_details.liability_insurance_name
                        };
                    }
                    else {
                        payload.user_detail = {
                            clinic: data.practice,
                            liability_insurance_name: data.doctor_details.liability_insurance_name,
                            registration_number: data.doctor_details.registration_number,
                            year_of_registration: data.doctor_details.year_of_registration,
                            state_medical_council_for_mci: data.doctor_details.state_medical_council_for_mci
                        };
                    }

                    return payload;
                }));
    };

    getMedicalAssitantPayload() {
        return this.store.select(GetRegistrationData)
            .pipe(
                map(data => {
                    return {
                        user_data: {
                            first_name: data.medical_assistant_details.first_name,
                            last_name: data.medical_assistant_details.last_name,
                            title: data.medical_assistant_details.title,
                            gender: data.medical_assistant_details.gender,
                            role: "medical_assistant"
                        },
                        user_avatar: data.user_avatar.indexOf("data:image/png;base64") > -1 ? this.dataURLtoFile(data.user_avatar) : null,
                        user_detail: {
                            title: data.medical_assistant_details.title,
                            degree: data.medical_assistant_details.degree
                        },
                        certificates: {
                            diploma_certificate: this.dataURLtoFile(data.certificates.diploma_certificate)
                        }
                    };
                }));
    }

    getPatientPayload() {
        return this.store.select(GetRegistrationData)
            .pipe(
                map(data => {
                    let payload: any = {
                        user_data: {
                            first_name: data.patient_details.first_name,
                            last_name: data.patient_details.last_name,
                            dob: data.patient_details.dob,
                            gender: data.patient_details.gender,
                            role: "USER"
                        },
                        user_avatar: data.user_avatar.indexOf("data:image/png;base64") > -1 ? this.dataURLtoFile(data.user_avatar) : null
                    };

                    if (data.insurance_type == "INSURANCE") {
                        payload.certificates = {
                            insurance_front: this.dataURLtoFile(data.certificates.insurance.front),
                            insurance_back: this.dataURLtoFile(data.certificates.insurance.back)
                        }
                    }

                    return payload;
                }));
    }

    save(data) {
        data.append("profile_complete", JSON.stringify(true));

        return this.doctorService.updateProfile({}, data)
            .pipe(
                map((data: any) => {
                    if (data.data && data.data.token) {
                        this.store.dispatch(SessionUpdate({
                            token: data.data.token
                        }));
                    }

                    this.toastr.success("User has been successfully updated");

                    return data;
                })
            );
    }

    updateDoctorProfile() {
        return this.getDoctorPayload()
            .pipe(
                first(),
                map(payload => {
                    let data = new FormData();

                    delete payload.user_data.role;

                    data.append("user_data", JSON.stringify(payload.user_data));
                    data.append("user_detail", JSON.stringify(payload.user_detail));
                    data.append("driver_license", payload.certificates.driver_license);
                    data.append("diploma_certificate", payload.certificates.diploma_certificate);

                    if (payload.signature) {
                        data.append("signature", payload.signature);
                    }

                    if (payload.user_avatar) {
                        data.append("user_avatar", payload.user_avatar);
                    }

                    return data;
                }),
                mergeMap((data) => {
                    return this.save(data);
                })
            );
    }

    updateAssistantOrPatient(role) {
        let observable;

        if (role == "PATIENT") {
            observable = this.getPatientPayload();
        }
        else {
            observable = this.getMedicalAssitantPayload();
        }

        return observable.pipe(
            first(),
            map((payload: any) => {
                let data = new FormData();

                if (payload.user_detail) {
                    data.append("user_detail", JSON.stringify(payload.user_detail));
                }

                if (payload.user_avatar) {
                    data.append("user_avatar", payload.user_avatar);
                }

                if (payload.user_data.role != 'medical_assistant') {
                    if (payload.certificates && payload.certificates.insurance_front) {
                        data.append("insurance_front", payload.certificates.insurance_front);
                        data.append("insurance_back", payload.certificates.insurance_back);
                    }

                    delete payload.user_data.role;
                    data.append("user_data", JSON.stringify($.extend(payload.user_data, {"appt_length": 30, "appt_start_time": "08:00 AM", "appt_end_time": "09:30 PM"})));
                }
                else if (payload.user_data.role == 'medical_assistant') {
                    if (payload.certificates.diploma_certificate) {
                        data.append("certification", payload.certificates.diploma_certificate);
                    }

                    delete payload.user_data.role;
                    data.append("user_data", JSON.stringify($.extend(payload.user_data, {"appt_length": 30, "appt_start_time": "08:00 AM", "appt_end_time": "09:30 PM"})));
                }

                return data;
            }),
            mergeMap((data) => {
                return this.save(data);
            })
        );
    }
}
