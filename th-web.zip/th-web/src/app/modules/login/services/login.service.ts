import { Injectable } from '@angular/core';

import { UrlService } from '../../../core/services/url.service';
import { RESTFactory } from '../../../core/factory/REST/REST.factory';

@Injectable({
    providedIn: 'root'
})
export class LoginService {
   public login;
   public checkAvailability;
   public generateOtp;
   public checkOtp;
   public resendEmailVerificationLink;
   public resetPassword;
   public getCountryCode;
   public whoAmI;
   public logout;

    constructor(private restFactory: RESTFactory) {
        this.login = this.restFactory.for({url: UrlService.LOGIN, method: 'POST'}, {});
        this.checkAvailability = this.restFactory.for({url: UrlService.CHECK_AVAILABILITY, method: "GET"}, {params: {app_type: "medical"}});
        this.generateOtp = this.restFactory.for({url: UrlService.GENERATE_OTP, method: "POST"}, {});
        this.checkOtp = this.restFactory.for({url: UrlService.CHECK_OTP, method: "POST"}, {});
        this.resendEmailVerificationLink = this.restFactory.for({url: UrlService.RESEND_EMAIL_VERIFICATION_LINK, method: "POST"}, {});
        this.resetPassword = this.restFactory.for({url: UrlService.RESET_PASSWORD, method: "POST"}, {});
        this.getCountryCode = this.restFactory.for({url: UrlService.GET_COUNTRY_CODE, method: "GET"}, {});
        this.whoAmI = this.restFactory.for({url: UrlService.WHO_AM_I, method: "GET"}, {});
        this.logout = this.restFactory.for({url: UrlService.LOGOUT, method: "POST"}, {});
    }
}