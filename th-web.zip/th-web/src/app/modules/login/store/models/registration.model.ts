export type Config = {
    type: string,
    role: string
}

export type Credentials = {
    email?: string,
    phone?: string,
    password?: string
    country_code?: string
}

export type Insurance = {
    front: string,
    back: string,
    front_secondary? : string,
    back_secondary? : string
}

export type Certificate = {
    diploma_certificate?: string,
    driver_license?: string,
    insurance?: Insurance
}

export type Practice = {
    clinic_name: string,
    street: string,
    suite: string,
    city: string,
    state: string,
    pin: number | string
}

export type License = {
    state_mo: string,
    no: number | string,
    expiry_date: string
}

export type DoctorDetails = {
    first_name: string,
    last_name: string,
    title: string,
    speciality: string,
    bio: string,
    gender: string,
    website: string,
    landline: number | string,
    official_phone: number | string,
    fax: number | string,
    liability_insurance_name: string,
    registration_number?: number | string,
    year_of_registration?: string,
    state_medical_council_for_mci?: string,
    npi?: string,
    licenses?: License[],
}

export type MedicalAssitantDetails = {
    first_name: string,
    last_name: string,
    title: string,
    degree: string,
    gender: string
}

export type PatientDetails = {
    first_name: string,
    last_name: string,
    dob: string,
    gender: string,
}

export type RegistrationData = {
    config?: Config,
    searchName?: string,
    practice?: Practice,
    practiceList?: any,
    doctor_details?: DoctorDetails,
    medical_assistant_details?: MedicalAssitantDetails,
    patient_details?: PatientDetails,
    signature?: string,
    certificates?: Certificate,
    credentials?: Credentials,
    user_avatar?: string,
    country_code?: string,
    user_guid?: string,
    insurance_type?: string,
    status?: string
};