export const DoctorDetail = {
    profile: {
        "first_name": '',
        "last_name": '',
        "title": '',
        "bio": '',
        "gender": '',
    },
    specialties: [],
    licenses: [
        {
            "state_mo": '',
            "no": '',
            "expiry_date": ''
        }
    ],
    npi: '',
    practices: []
}