import {RegistrationData} from "./registration.model";
import {forgotPassword} from "./forgot-password.model";

export type LoginState = {
    registrationData: RegistrationData,
    forgotPasswordData: forgotPassword
}