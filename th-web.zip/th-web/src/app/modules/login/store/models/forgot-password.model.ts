export type forgotPassword = {
    email?: any,
    password?: any,
    confirm_password?: any,
    otp?: any,
    app_type?: any
}