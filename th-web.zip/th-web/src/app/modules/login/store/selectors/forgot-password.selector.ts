import { createSelector, createFeatureSelector } from '@ngrx/store';

import { AppState } from '../../../../core/store/models/appState.model';
import { LoginState } from '../models/login-state.model';

const selectLogin = createFeatureSelector<AppState, LoginState>("login");

export const GetForgotPasswordData = createSelector(
    selectLogin,
    (state: LoginState) => state.forgotPasswordData
);