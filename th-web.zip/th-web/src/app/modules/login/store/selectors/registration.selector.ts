import { createSelector, createFeatureSelector } from '@ngrx/store';

import { AppState } from '../../../../core/store/models/appState.model';
import { LoginState } from '../models/login-state.model';

const selectLogin = createFeatureSelector<AppState, LoginState>("login");

export const GetRegistrationData = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData
);

export const GetConfig = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.config
);

export const GetSearchName = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.searchName
);

export const GetPractice = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.practice
);

export const GetPracticeList = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.practiceList
);

export const GetDoctorDetails = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.doctor_details
);

export const GetMedicalAssistantDetails = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.medical_assistant_details
);

export const GetPatientDetails = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.patient_details
);

export const GetSignature = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.signature
);

export const GetCertificates = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.certificates
);

export const GetCredentials = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.credentials
);

export const GetUserAvatar = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.user_avatar
);

export const GetUserGuid = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.user_guid
);

export const GetInsuranceType = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.insurance_type
);

export const GetStatus = createSelector(
    selectLogin,
    (state: LoginState) => state.registrationData.status
);
