import {createReducer, on, Action} from '@ngrx/store'

import * as $ from 'jquery';

import { ForgotPasswordDataUpdate, ForgotPasswordDataReset } from "../actions/forgot-password.actions";
import {forgotPassword} from "../models/forgot-password.model";

const initialData = {

};

const forgotPasswordReducerFactory = createReducer(
    initialData,
    on(ForgotPasswordDataUpdate, (state: forgotPassword, prop) => {
        let newProp = {...prop};

        delete newProp.type;

        return $.extend(true, {}, state, newProp);
    }),
    on(ForgotPasswordDataReset, (state, prop) => {
        return {};
    })
);

export function  ForgotPasswordDataReducer(state: forgotPassword, action: Action) {
    return forgotPasswordReducerFactory(state, action);
}