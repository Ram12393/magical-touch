import { createReducer, on, Action} from '@ngrx/store';

import * as $ from 'jquery';

import { RegistrationDataUpdate, RegistrationDataReset } from '../actions/registration.actions';
import { RegistrationData } from "../models/registration.model";

const initialData = {} as RegistrationData;

const RegistrationDataReducerFactory = createReducer(
    initialData,
    on(RegistrationDataUpdate, (state, prop) => {
        let newProp = {...prop};

        delete newProp.type;

        return $.extend(true, {}, state, newProp);
    }),
    on(RegistrationDataReset, (state, prop) => {
       return {};
    })
);

export function RegistrationDataReducer (state: RegistrationData = initialData, action: Action) {
    return RegistrationDataReducerFactory(state, action);
}