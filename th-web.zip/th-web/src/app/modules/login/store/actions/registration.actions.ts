import { createAction, props } from '@ngrx/store';

import { RegistrationData } from '../models/registration.model';

export const RegistrationDataUpdate = createAction(
    "[Registration component] update data",
    props<RegistrationData>()
);

export const RegistrationDataReset = createAction(
    "[Registration component] reset data",
    props<{}>()
)