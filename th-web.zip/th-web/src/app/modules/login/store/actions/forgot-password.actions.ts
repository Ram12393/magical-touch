import {createAction, props} from "@ngrx/store";
import {forgotPassword} from "../models/forgot-password.model";

export const ForgotPasswordDataUpdate = createAction(
    "[ForgotPassword component] update data",
    props<forgotPassword>()
);

export const ForgotPasswordDataReset = createAction(
    "[ForgotPassword component] reset data",
    props<{}>()
)