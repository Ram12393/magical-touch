import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { OnboardingComponent } from './pages/onboarding/onboarding.component';

const routes: Routes = [
  {
    path: "login",
    component: LoginComponent,
    data: {
      hideMenu: true
    }
  },
  {
    path: "registration",
    component: RegistrationComponent,
    data: {
      hideMenu: true
    }
  },
  {
    path: "forgot-password",
    component: ForgotPasswordComponent,
    data: {
      hideMenu: true
    }
  },
  {
    path: "onboarding",
    component: OnboardingComponent,
    data: {
      hideMenu: true
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRouteRoutingModule { }
