import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

import { Store } from "@ngrx/store";

import { GetSettings } from '../../../../core/store/selectors/settings.selector';
import {GetConfig} from "../../store/selectors/registration.selector";
import {first} from "rxjs/internal/operators";

@Component({
  selector: 'app-registration-terms-and-condition',
  templateUrl: 'registration-terms-and-condition.component.html',
  styleUrls: ['registration-terms-and-condition.component.scss']
})
export class RegistrationTermsAndConditionComponent implements OnInit {
  @Output() next = new EventEmitter();
  @Output() prev = new EventEmitter();
  public type: string;
  public role: string;
  public showInfoRelease = false;
  settings = {};

  constructor(private store: Store<{}>) {
    this.store.select(GetSettings)
        .pipe(first())
        .subscribe((settings) => {
          this.settings = settings;
        });

    this.store.select(GetConfig)
        .pipe(first())
        .subscribe(config => {
            this.type = config.type;
            this.role = config.role;
        });
  }

  ngOnInit() {
  }
}
