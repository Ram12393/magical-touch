import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationTermsAndConditionComponent } from './registration-terms-and-condition.component';

describe('RegistrationTermsAndConditionComponent', () => {
  let component: RegistrationTermsAndConditionComponent;
  let fixture: ComponentFixture<RegistrationTermsAndConditionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationTermsAndConditionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationTermsAndConditionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
