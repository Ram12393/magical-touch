import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {Store} from "@ngrx/store";

import {ForgotPasswordDataUpdate} from "../../store/actions/forgot-password.actions";
import {PasswordValidator} from "../../../../shared/validators/password.validator";
import {GetForgotPasswordData} from "../../store/selectors/forgot-password.selector";
import {first} from "rxjs/internal/operators";
import {forgotPassword} from "../../store/models/forgot-password.model";

@Component({
    selector: 'app-forgot-password-new-password',
    templateUrl: 'forgot-password-new-password.component.html',
    styleUrls: ['forgot-password-new-password.component.scss']
})
export class ForgotPasswordNewPasswordComponent implements OnInit {
    @Output() next = new EventEmitter();
    public model;

    constructor(public store: Store<{}>) {
        this.store.select(GetForgotPasswordData)
            .pipe(first())
            .subscribe((data: forgotPassword) => {
                this.model = {
                    password: new FormControl(data.password || '', [
                        Validators.required,
                        PasswordValidator
                    ])
                }
            });
    }

    ngOnInit() {
    }

    isValid() {
        return this.model.password.valid;
    }

    onNext() {
        if (!this.isValid()) {
            return;
        }

        this.store.dispatch(ForgotPasswordDataUpdate({
            password: this.model.password.value
        }));

        this.next.emit();
    }
}
