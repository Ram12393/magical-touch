import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationAssistantDetailsComponent } from './registration-assistant-details.component';

describe('RegistrationAssistantDetailsComponent', () => {
  let component: RegistrationAssistantDetailsComponent;
  let fixture: ComponentFixture<RegistrationAssistantDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationAssistantDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationAssistantDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
