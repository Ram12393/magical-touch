import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

import { PatternValidator } from '../../../../shared/validators/pattern.validator';
import { RegexConstants } from '../../../../core/config/regex';
import { FormValidationErrorMessages } from '../../../../core/config/form-validation-error-messages';
import {Store} from "@ngrx/store";
import {GetRegistrationData} from "../../store/selectors/registration.selector";
import {first} from "rxjs/internal/operators";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";

@Component({
  selector: 'app-registration-assistant-details',
  templateUrl: 'registration-assistant-details.component.html',
  styleUrls: ['registration-assistant-details.component.scss']
})
export class RegistrationAssistantDetailsComponent implements OnInit {
  @Output() next = new EventEmitter();
  public model;
  public userAvatar;
  public availableTitles = ["RN","NP", "LPN", "LVN", "CNA", "CNM", "CRNA", "DNP", "MA", "RMA", "PA", "FNP", "OTHER"];
  public availableGender = ["male", "female", "other"];
  
  constructor(private store: Store<{}>) {
    this.store.select(GetRegistrationData)
        .pipe(first())
        .subscribe(data => {
          this.userAvatar = data.user_avatar;
          this.model = {
            "first_name": new FormControl(data.medical_assistant_details.first_name, [
              Validators.required,
              PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
            ]),
            "last_name": new FormControl(data.medical_assistant_details.last_name, [
              Validators.required,
              PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
            ]),
            "title": new FormControl(data.medical_assistant_details.title, [
              Validators.required
            ]),
            "degree": new FormControl(data.medical_assistant_details.degree, [
              Validators.required,
              PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
            ]),
            "gender": new FormControl(data.medical_assistant_details.gender, [
              Validators.required
            ]),
          }
        });
  }

  ngOnInit() {
  }

  isValid() {
    for (let i in this.model) {
      if (!this.model[i].valid) {
        return false;
      }
    }

    return true;
  }

  onNext() {
    this.store.dispatch(RegistrationDataUpdate({
      medical_assistant_details: {
        "first_name": this.model.first_name.value,
        "last_name": this.model.last_name.value,
        "title": this.model.title.value,
        "degree": this.model.degree.value,
        "gender": this.model.gender.value
      },
      user_avatar: this.userAvatar
    }));
    this.next.emit();
  }

}
