import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationEmailLookupComponent } from './registration-email-lookup.component';

describe('RegistrationEmailLookupComponent', () => {
  let component: RegistrationEmailLookupComponent;
  let fixture: ComponentFixture<RegistrationEmailLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationEmailLookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationEmailLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
