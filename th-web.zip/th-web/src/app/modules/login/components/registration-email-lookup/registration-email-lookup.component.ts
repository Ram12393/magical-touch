import {Component, OnInit, EventEmitter, Output, OnDestroy} from '@angular/core';
import {FormControl, Validators, AbstractControl} from "@angular/forms";

import { RegexConstants } from '../../../../core/config/regex';
import { PatternValidator } from '../../../../shared/validators/pattern.validator';
import { FormValidationErrorMessages } from '../../../../core/config/form-validation-error-messages';

import {LoginService} from '../../services/login.service';
import {Store} from "@ngrx/store";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {GetCredentials} from "../../store/selectors/registration.selector";
import {EmailAvailabilityValidator} from "../../../../shared/validators/email-availability.validator.async";

@Component({
    selector: 'app-registration-email-lookup',
    templateUrl: 'registration-email-lookup.component.html',
    styleUrls: ['registration-email-lookup.component.scss']
})
export class RegistrationEmailLookupComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    public model;
    public emailSubscription$;

    constructor(private loginService: LoginService, private store: Store<{}>) {
        this.emailSubscription$ = this.store.select(GetCredentials)
            .subscribe((credentails) => {
                let email = credentails ? credentails.email : '';

                this.model = {
                    'email': new FormControl(email, [
                            Validators.required,
                            PatternValidator(RegexConstants.email, FormValidationErrorMessages.email)
                        ],
                        [
                            EmailAvailabilityValidator(loginService, (data: {available: boolean}) => {
                                return !data.available ? {availability: "Email id is already registered."} : null;
                            })
                        ])
                };
            });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.emailSubscription$.unsubscribe();
    }

    isValid() {
        return this.model.email.valid;
    }

    onNext() {
        this.store.dispatch(RegistrationDataUpdate({
            credentials: {
                email: this.model.email.value
            }
        }));

        this.next.emit();
    }
}
