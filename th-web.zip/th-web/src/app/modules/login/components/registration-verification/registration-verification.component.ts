import {Component, OnInit, Output, EventEmitter, ViewEncapsulation} from '@angular/core';

import {LoginService} from '../../services/login.service';
import {ToastrService} from '../../../../core/services/toastr.service';
import {Store} from '@ngrx/store';
import {GetUserGuid} from '../../store/selectors/registration.selector';
import {first} from 'rxjs/internal/operators';
import {RegistrationDataUpdate} from '../../store/actions/registration.actions';
import {SessionUpdate} from '../../../../core/store/actions/session.action';

@Component({
    selector: 'app-registration-verification',
    templateUrl: 'registration-verification.component.html',
    styleUrls: ['registration-verification.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class RegistrationVerificationComponent implements OnInit {
    public user_guid;
    @Output() next = new EventEmitter();
    public loading;

    constructor(public loginService: LoginService, public toastr: ToastrService, private store: Store<{}>) {
        this.store.select(GetUserGuid)
            .pipe(first())
            .subscribe(id => this.user_guid = id);
    }

    ngOnInit() {
        this.generate();
    }

    validate(code) {
        this.loading = true;
        this.loginService.checkOtp({},
            {
                user_guid: this.user_guid,
                otp: code
            })
            .subscribe((result) => {
                    if (result.success) {
                        this.store.dispatch(SessionUpdate({
                            token: result.data.token
                        }));
                        this.next.emit();
                    }
                    this.loading = false;
                },
                (data) => {
                    this.toastr.error(data.error.message);
                    this.loading = false;
                });
    }

    generate() {
        this.loading = true;
        this.loginService.generateOtp({},
            {
                user_guid: this.user_guid
            })
            .subscribe(() => {
                    this.loading = false;
                },
                (data) => {
                    this.toastr.error(data.error.message);
                    this.loading = false;
                });
    }

}
