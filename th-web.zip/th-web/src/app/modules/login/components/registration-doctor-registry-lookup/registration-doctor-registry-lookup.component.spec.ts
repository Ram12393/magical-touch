import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationDoctorRegistryLookupComponent } from './registration-doctor-registry-lookup.component';

describe('RegistrationDoctorRegistryLookupComponent', () => {
  let component: RegistrationDoctorRegistryLookupComponent;
  let fixture: ComponentFixture<RegistrationDoctorRegistryLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationDoctorRegistryLookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationDoctorRegistryLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
