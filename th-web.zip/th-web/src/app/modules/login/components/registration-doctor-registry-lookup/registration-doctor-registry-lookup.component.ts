import {Component, OnInit, Input, Output, EventEmitter, OnDestroy} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {DoctorService} from '../../../../core/services/doctor.service';
import {Store} from "@ngrx/store";
import {GetSearchName} from "../../store/selectors/registration.selector";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";

@Component({
    selector: 'app-registration-doctor-registry-lookup',
    templateUrl: 'registration-doctor-registry-lookup.component.html',
    styleUrls: ['registration-doctor-registry-lookup.component.scss']
})
export class RegistrationDoctorRegistryLookupComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    public name: FormControl;
    public typeahead: any = [];
    private typeaheadRequestConfig: any;
    private typeaheadInflight;
    private searchNameSubscription$;

    constructor(private doctorService: DoctorService, private store: Store<{}>) {
        this.resetTypeaheadConfig();
        this.searchNameSubscription$ = this.store.select(GetSearchName)
            .subscribe((searchName = '') => {
                this.name = new FormControl(searchName, [
                    Validators.required
                ]);
            });
        this.name.valueChanges.subscribe(() => {
            if (this.name.value) {
                this.getTypeaheadList();
            }

            this.resetTypeaheadConfig();
        });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.searchNameSubscription$.unsubscribe();
    }

    getTypeaheadList() {
        if (this.typeaheadInflight) {
            this.typeaheadInflight.unsubscribe();
        }

        if (this.name.value) {
            this.typeahead.loading = true;
            this.typeaheadInflight = this.doctorService.getDoctor({
                    params: {
                        name: this.name.value,
                        typeahead: true,
                        page: ++this.typeaheadRequestConfig.page,
                        page_size: this.typeaheadRequestConfig.page_size
                    }
                })
                .subscribe((result) => {
                        this.typeahead.push.apply(this.typeahead, result.data);
                        this.typeahead.loading = false;
                    },
                    () => {
                        this.typeahead.loading = false;
                    });
        }
    }

    resetTypeaheadConfig() {
        this.typeahead.length = 0;
        this.typeaheadRequestConfig = {
            page: 0,
            page_size: 10
        };
    }

    onNext() {
        this.store.dispatch(RegistrationDataUpdate({
            searchName: this.name.value
        }));
        this.next.emit();
    }
}
