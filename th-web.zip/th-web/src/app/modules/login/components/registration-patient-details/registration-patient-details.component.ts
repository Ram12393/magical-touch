import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl} from '@angular/forms';

import {Validators} from '@angular/forms';
import {RegexConstants} from '../../../../core/config/regex';
import {PatternValidator} from '../../../../shared/validators/pattern.validator';
import {FormValidationErrorMessages} from '../../../../core/config/form-validation-error-messages';
import {Store} from "@ngrx/store";
import {GetPatientDetails, GetRegistrationData} from "../../store/selectors/registration.selector";
import {first} from "rxjs/internal/operators";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";

@Component({
    selector: 'app-registration-patient-details',
    templateUrl: 'registration-patient-details.component.html',
    styleUrls: ['registration-patient-details.component.scss']
})
export class RegistrationPatientDetailsComponent implements OnInit {
    @Output() next = new EventEmitter();
    public model;
    public userAvatar;
    public availableGender = ["male", "female", "other"];
    public dobMax: Date = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

    constructor(private store: Store<{}>) {
        this.store.select(GetRegistrationData)
            .pipe(first())
            .subscribe(data => {
                this.userAvatar = data.user_avatar;
                this.model = {
                    "first_name": new FormControl(data.patient_details.first_name, [
                        Validators.required,
                        PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
                    ]),
                    "last_name": new FormControl(data.patient_details.last_name, [
                        Validators.required,
                        PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
                    ]),
                    "dob": new FormControl(data.patient_details.dob, [
                        Validators.required,
                        PatternValidator(RegexConstants.date, FormValidationErrorMessages.date)
                    ]),
                    "gender": new FormControl(data.patient_details.gender, [
                        Validators.required
                    ]),
                }
            });
    }

    ngOnInit() {
    }

    isValid() {
        for (let i in this.model) {
            if (!this.model[i].valid) {
                return false;
            }
        }

        return true;
    }

    onNext() {
        this.store.dispatch(RegistrationDataUpdate({
            patient_details: {
                "first_name": this.model.first_name.value,
                "last_name": this.model.last_name.value,
                "dob": this.model.dob.value,
                "gender": this.model.gender.value,
            },
            user_avatar: this.userAvatar
        }));
        this.next.emit();
    }
}
