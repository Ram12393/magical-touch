import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationPatientDetailsComponent } from './registration-patient-details.component';

describe('RegistrationPatientDetailsComponent', () => {
  let component: RegistrationPatientDetailsComponent;
  let fixture: ComponentFixture<RegistrationPatientDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationPatientDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationPatientDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
