import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationDoctorRegistryChoosePractiseComponent } from './registration-doctor-registry-choose-practise.component';

describe('RegistrationDoctorRegistryChoosePractiseComponent', () => {
  let component: RegistrationDoctorRegistryChoosePractiseComponent;
  let fixture: ComponentFixture<RegistrationDoctorRegistryChoosePractiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationDoctorRegistryChoosePractiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationDoctorRegistryChoosePractiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
