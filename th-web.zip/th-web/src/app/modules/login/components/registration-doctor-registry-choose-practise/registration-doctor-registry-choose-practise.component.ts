import {Component, OnInit, Input, Output, EventEmitter, OnDestroy} from '@angular/core';
import {FormControl} from "@angular/forms";
import {Store} from "@ngrx/store";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {GetPracticeList, GetRegistrationData} from "../../store/selectors/registration.selector";

@Component({
  selector: 'app-registration-doctor-registry-choose-practise',
  templateUrl: 'registration-doctor-registry-choose-practise.component.html',
  styleUrls: ['registration-doctor-registry-choose-practise.component.scss']
})
export class RegistrationDoctorRegistryChoosePractiseComponent implements OnInit, OnDestroy {
  @Output() next = new EventEmitter();
  @Output() prev = new EventEmitter();
  public search = new FormControl('');
  public practices = [];
  public registrationSubscription$;
  public details;

  constructor(private store: Store<{}>) {
    this.registrationSubscription$ = this.store.select(GetRegistrationData)
        .subscribe(data => {
          this.practices = data.practiceList;
          this.details = data.doctor_details;
        });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.registrationSubscription$.unsubscribe();
  }

  selectPractise(practise) {
    this.store.dispatch(RegistrationDataUpdate({
      practice: {
        "clinic_name": practise.name,
        "street": practise.visit_address.street,
        "suite": '',
        "city": practise.visit_address.city,
        "state": practise.visit_address.state,
        "pin": practise.visit_address.zip
      }
    }));
    this.next.emit();
  }
}
