import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import { Store } from "@ngrx/store";

import { LoginService } from '../../services/login.service';
import { SessionUpdate } from '../../../../core/store/actions/session.action';
import { GetSettings } from '../../../../core/store/selectors/settings.selector';
import {RegexConstants} from "../../../../core/config/regex";
import {PatternValidator} from "../../../../shared/validators/pattern.validator";
import {FormValidationErrorMessages} from "../../../../core/config/form-validation-error-messages";
import {ToastrService} from "../../../../core/services/toastr.service";
import {Router} from "@angular/router";
import {RegistrationDataUpdate, RegistrationDataReset} from "../../store/actions/registration.actions";
import {SettingsUpdate} from "../../../../core/store/actions/settings.action";
import {AuthService} from "../../../../core/services/auth.service";

@Component({
    selector: 'app-signin',
    templateUrl: 'signin.component.html',
    styleUrls: ['signin.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class SigninComponent implements OnInit {
    public model;
    public settings = {};
    public loading:boolean = false;

    constructor(private loginService: LoginService, private store: Store<{}>, private toastr: ToastrService, public route: Router, private auth: AuthService) {

        this.model = {
            'email': new FormControl('', [
                Validators.required,
                PatternValidator(RegexConstants.email, FormValidationErrorMessages.email)
            ]),
            'password': new FormControl('', [
                Validators.required
            ])
        };

        this.store.select(GetSettings)
            .subscribe((settings) => {
                this.settings = settings;
            });

        this.store.dispatch(RegistrationDataReset({}));
    }

    ngOnInit() {
    }

    isValid() {
        return this.model.email.valid && this.model.password.valid;
    }

    onLogin() {
        this.loading = true;
        this.loginService.login({}, {
                "email": this.model.email.value,
                "password": this.model.password.value
            })
            .subscribe((data) => {
                    this.loading = false;
                    if (data.success) {
                        this.store.dispatch(SessionUpdate({
                            token: data.token
                        }));
                        this.redirectAfterLogin();
                    }
                },
                (data) => {
                    if (data.error.locked) {
                       let timeout = (data.error.lockTimeInMins > 60 ? (data.error.lockTimeInMins / 60) + " hours" : data.error.lockTimeInMins + " minutes");
                        this.toastr.confirm(`Your account has been locked out for the next ${ timeout }. Either you can wait or reset your password.`, {
                                primaryButton: "reset password",
                                secondButton: "cancel"
                            })
                            .subscribe((resetPassword) => {
                                if (resetPassword) {
                                    this.route.navigate(["/forgot-password"])
                                }
                                else {
                                    this.reset();
                                }
                            });
                    }
                    else {
                        this.toastr.error("Unable to login. please ensure that your email and password are entered correctly and try again");   
                    }
                    this.loading = false;
                });
    }

    redirectAfterLogin() {
        this.loading = true;

        this.auth.validateSession("/patients")
            .subscribe(() => {
                    this.loading = false;
                },
                () => {
                    this.loading = false;
                    this.toastr.error("Unable to login. please ensure that your email and password are entered correctly and try again");
                })
    }

    reset() {
        this.model = {
            'email': new FormControl('', [
                Validators.required,
                PatternValidator(RegexConstants.email, FormValidationErrorMessages.email)
            ]),
            'password': new FormControl('', [
                Validators.required
            ])
        };
    }
}
