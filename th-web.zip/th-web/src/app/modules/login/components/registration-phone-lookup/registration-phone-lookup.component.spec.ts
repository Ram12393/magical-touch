import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationPhoneLookupComponent } from './registration-phone-lookup.component';

describe('RegistrationPhoneLookupComponent', () => {
  let component: RegistrationPhoneLookupComponent;
  let fixture: ComponentFixture<RegistrationPhoneLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationPhoneLookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationPhoneLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
