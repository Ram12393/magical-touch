import {Component, OnInit, Output, EventEmitter, OnDestroy} from '@angular/core';
import {Validators, FormControl, AbstractControl} from '@angular/forms';

import {RegexConstants} from '../../../../core/config/regex';
import {FormValidationErrorMessages} from '../../../../core/config/form-validation-error-messages';
import {Store} from "@ngrx/store";
import {GetCredentials  } from "../../store/selectors/registration.selector";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {first} from "rxjs/internal/operators";
import {GetSession} from "../../../../core/store/selectors/session.selector";
import {Session} from "../../../../core/store/models/session.model";
import {SessionUpdate} from "../../../../core/store/actions/session.action";

@Component({
    selector: 'app-registration-phone-lookup',
    templateUrl: 'registration-phone-lookup.component.html',
    styleUrls: ['registration-phone-lookup.component.scss']
})
export class RegistrationPhoneLookupComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    public model: {code: any, phone: any} = {code: '', phone: ''};
    public countryCode$;

    constructor(private store: Store<{}>) {
        this.model = {
            'code': new FormControl('', [
                Validators.required
            ]),
            'phone': new FormControl('', [
                Validators.required,
                this.checkphoneNumber()
            ])
        };

        this.store.select(GetCredentials)
            .pipe(first())
            .subscribe((credentials) => {
                this.model.phone.setValue(credentials.phone || '');
            });

        this.countryCode$ = this.store.select(GetSession)
            .subscribe((session: Session) => {
                this.model.code.setValue(session.country == 'IN' ? '+91' : '+1');
            });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.countryCode$.unsubscribe();
    }

    checkphoneNumber() {
        return (control: AbstractControl) => {
            if (control.value) {
                if (this.model.code.value == '+1') {
                    return !control.value.match(RegexConstants.usPhone) ? {custom: FormValidationErrorMessages.mobile} : null;
                }
                else {
                    return !(control.value.match(RegexConstants.mobile)) || (control.value.length < 10 || control.value.length > 10) ? {custom: FormValidationErrorMessages.mobile} : null;
                }
            }
        }
    }

    isValid() {
        return this.model.phone.valid;
    }

    setCountryCode(code) {
        this.store.dispatch(SessionUpdate({
            country: code == "+91" ? "IN" : "USA"
        }));
    }

    onNext() {
        this.store.dispatch(RegistrationDataUpdate({
            credentials: {
                phone: this.model.phone.value,
                country_code: this.model.code.value
            }
        }));
        this.next.emit();
    }
}
