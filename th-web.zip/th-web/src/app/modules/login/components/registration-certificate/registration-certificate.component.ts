import {Component, OnInit, Output, EventEmitter, Input, OnDestroy} from '@angular/core';
import {Store} from "@ngrx/store";
import {Insurance} from "../../store/models/registration.model";
import {GetCertificates, GetConfig} from "../../store/selectors/registration.selector";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {RegistrationHelperService} from "../../services/registration-helper.service";

@Component({
    selector: 'app-registration-certificate',
    templateUrl: 'registration-certificate.component.html',
    styleUrls: ['registration-certificate.component.scss']
})
export class RegistrationCertificateComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    public medicalCertificates: string = '';
    public drivingCertificates: string = '';
    public insurance: Insurance = {front: '', back: '', front_secondary: '', back_secondary: ''};
    private certificateSubscriptions$;
    private configSubscriptions$;
    public role: string;
    public loading: boolean = false;

    constructor(private store: Store<{}>, private registrationHelper: RegistrationHelperService) {
        this.certificateSubscriptions$ = this.store.select(GetCertificates)
            .subscribe(d => {
                if (d) {
                    if (d.diploma_certificate) {
                        this.medicalCertificates = d.diploma_certificate;
                    }

                    if (d.driver_license) {
                        this.drivingCertificates = d.driver_license;
                    }

                    if (d.insurance) {
                        this.insurance = {
                            front: d.insurance.front,
                            back: d.insurance.back,
                            front_secondary: d.insurance.front_secondary,
                            back_secondary: d.insurance.back_secondary
                        }
                    }
                }
            });

        this.configSubscriptions$ = this.store.select(GetConfig)
            .subscribe(config => {
                this.role = config.role;
            });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.certificateSubscriptions$.unsubscribe();
        this.configSubscriptions$.unsubscribe();
    }

    addMedicalCertificate(image) {
        this.medicalCertificates = image;
    }

    addDrivingCertificate(image) {
        this.drivingCertificates = image;
    }

    addInsurance(image, side) {
        this.insurance[side] = image;
    }

    isValid() {
        if (this.role == "DOCTOR/EXTENDER") {
            return this.medicalCertificates && this.drivingCertificates;
        }
        else if (this.role == "OFFICE ASSISTANT") {
            return this.medicalCertificates;
        }
        else if (this.role == "PATIENT") {
            return this.insurance.front && this.insurance.back && (!!this.insurance.front_secondary == !!this.insurance.back_secondary);
        }
    }

    onFinish() {
        let data = {};
        if (this.role == "DOCTOR/EXTENDER") {
            data = {
                diploma_certificate: this.medicalCertificates,
                driver_license: this.drivingCertificates
            };
        }
        else if (this.role == "OFFICE ASSISTANT") {
            data = {
                diploma_certificate: this.medicalCertificates,
            }
        }
        else if (this.role == "PATIENT") {
            data = {
                insurance: this.insurance
            }
        }

        this.store.dispatch(RegistrationDataUpdate({
            certificates: data
        }));

        if (this.role != "DOCTOR/EXTENDER") {
            this.loading = true;
            this.registrationHelper.updateAssistantOrPatient(this.role)
                .subscribe(data => {
                        this.loading = false;
                        this.next.emit();
                    },
                    () => {
                        this.loading = false;
                    });
        }
        else {
            this.next.emit();
        }
    }
}
