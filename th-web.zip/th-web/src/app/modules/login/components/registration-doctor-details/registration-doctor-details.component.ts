import {Component, OnInit, Input, ViewEncapsulation, Output, EventEmitter} from '@angular/core';
import { FormControl, Validators, AbstractControl } from '@angular/forms';

import { Store } from '@ngrx/store';
import { combineLatest } from "rxjs";

import { PatternValidator } from '../../../../shared/validators/pattern.validator';
import { RegexConstants } from '../../../../core/config/regex';
import { FormValidationErrorMessages } from '../../../../core/config/form-validation-error-messages';
import { GetRegistrationData } from "../../store/selectors/registration.selector";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {DoctorDetails, Practice} from "../../store/models/registration.model";
import {first} from "rxjs/internal/operators";

@Component({
    selector: 'app-registration-doctor-details',
    templateUrl: 'registration-doctor-details.component.html',
    styleUrls: ['registration-doctor-details.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class RegistrationDoctorDetailsComponent implements OnInit {
    @Input() details;
    @Input() countryCode;
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    private model;
    public label: string = "test";
    public expiryMin: Date = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
    public yearOfRegistrationMax: Date = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
    public userAvatar: string = "test";
    public specialities: string[] = [
        "Obstetrics & Gynecology",
        "Orthopedics",
        "Podiatry",
        "Family Medicine",
        "Internal Medicine",
        "Pediatrics",
        "Neurology",
        "Dermatology",
        "Opthamology",
        "Urology",
        "ENT",
        "Pain Medicine",
        "Infectious Disease",
        "Sports Medicine",
        "Psychiatry",
        "Allergy & Immunology",
        "Hematology & Oncology",
        "Other"
    ];
    public availableStates = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"];
    public availableGender = ["male", "female", "other"];

    constructor(private store: Store<{}>) {
        this.store.select(GetRegistrationData)
            .pipe(first())
            .subscribe((data: any) => {
                this.countryCode = data.credentials.country_code;
                this.userAvatar = data.user_avatar;
                this.model = {
                    "first_name": new FormControl(data.doctor_details.first_name, [
                        Validators.required,
                        PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
                    ]),
                    "last_name": new FormControl(data.doctor_details.last_name, [
                        Validators.required,
                        PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
                    ]),
                    "title": new FormControl(data.doctor_details.title, [
                        Validators.required,
                        PatternValidator(RegexConstants.alphabet, FormValidationErrorMessages.alphabet)
                    ]),
                    "speciality": new FormControl(data.doctor_details.speciality, [
                        Validators.required
                    ]),
                    "bio": new FormControl(data.doctor_details.bio, [
                        Validators.required
                    ]),
                    "gender": new FormControl(data.doctor_details.gender, [
                        Validators.required
                    ]),
                    "website": new FormControl(data.doctor_details.website, [
                        PatternValidator(RegexConstants.url, FormValidationErrorMessages.url)
                    ]),
                    "landline": new FormControl(data.doctor_details.landline, [
                        PatternValidator(RegexConstants.number, FormValidationErrorMessages.number)
                    ]),
                    "official_phone": new FormControl(data.doctor_details.official_phone, [
                        PatternValidator(RegexConstants.number,FormValidationErrorMessages.number)
                    ]),
                    "fax": new FormControl(data.doctor_details.fax, [
                        PatternValidator(RegexConstants.number,FormValidationErrorMessages.number)
                    ]),
                    "liability_insurance_name": new FormControl(data.doctor_details.liability_insurance_name, [
                        Validators.required
                    ]),
                    "practice": {
                        "clinic_name": new FormControl(data.practice.clinic_name, [
                            Validators.required
                        ]),
                        "street": new FormControl(data.practice.street, [
                            Validators.required
                        ]),
                        "suite": new FormControl(data.practice.suite),
                        "city": new FormControl(data.practice.city, [
                            Validators.required
                        ]),
                        "state": new FormControl(data.practice.state, [
                            Validators.required
                        ]),
                        "pin": new FormControl(data.practice.pin, [
                            Validators.required,
                            PatternValidator(RegexConstants.number, FormValidationErrorMessages.number),
                            this.checkPinOrZipCode()
                        ])
                    }
                };

                if (this.countryCode != "+1") {
                    this.model.registration_number = new FormControl(data.doctor_details.registration_number, [
                        Validators.required
                    ]);
                    this.model.year_of_registration = new FormControl(data.doctor_details.year_of_registration, [
                        Validators.required,
                        PatternValidator(RegexConstants.date, FormValidationErrorMessages.date)
                    ]);
                    this.model.state_medical_council_for_mci = new FormControl(data.doctor_details.state_medical_council_for_mci, [
                        Validators.required
                    ]);
                }
                else {
                    this.model.licenses = [];
                    this.model.npi = new FormControl(data.doctor_details.npi, [
                        Validators.required
                    ]);

                    if (data.doctor_details.licenses.length) {
                        data.doctor_details.licenses.forEach((d) => {
                            this.model.licenses.push({
                                "state_mo": new FormControl(d.state_mo, [
                                    Validators.required
                                ]),
                                "no": new FormControl(d.no, [
                                    Validators.required
                                ]),
                                "expiry_date": new FormControl(d.expiry_date, [
                                    Validators.required,
                                    PatternValidator(RegexConstants.date, FormValidationErrorMessages.date),
                                ])
                            });
                        });
                    }
                }
            });
    }

    ngOnInit() {
    }

    addLicense() {
        this.model.licenses.push({
            "state_mo": new FormControl('', [
                Validators.required
            ]),
            "no": new FormControl('', [
                Validators.required,
                PatternValidator(/^[0-9a-zA-Z]*$/, FormValidationErrorMessages.alphanumeric)
            ]),
            "expiry_date": new FormControl('', [
                Validators.required,
                PatternValidator(RegexConstants.date, FormValidationErrorMessages.date),
            ])
        });
    }

    isValid() {
        for (let i in this.model) {
            if (i == "practice") {
                for (let j in this.model.practice) {
                    if (!this.model.practice[j].valid) {
                        return false;
                    }
                }
            }
            else if (i == 'licenses') {
                for (let k = 0; k < this.model.licenses.length; k++) {
                    for (let j in this.model.licenses[k]) {
                        if (!this.model.licenses[k][j].valid) {
                            return false;
                        }
                    }
                }
            }
            else if (!this.model[i].valid) {
                return false;
            }
        }
        return true;
    }



    onNext() {
        var details = {} as DoctorDetails,
            practise = {} as Practice;

        for (let i in this.model) {
            if (i != 'practice') {
                if (this.model[i].push) {
                    details[i] = this.model[i].map(d => {
                            let license = {};
                            for (let k in d) {
                                license[k] = d[k].value;
                            }
                            return license;
                        });
                }
                else {
                    details[i] = this.model[i].value;
                }
            }
            else {
                for(let j in this.model[i]) {
                    practise[j] = this.model[i][j].value;
                }
            }
        }

        this.store.dispatch(RegistrationDataUpdate({
            doctor_details: details,
            practice: practise,
            user_avatar: this.userAvatar
        }));

        this.next.emit();
    }

    allowLicenseAdd() {
        if (!this.model.licenses) {
            return;
        }

        for (let i = 0; i < this.model.licenses.length; i++) {
            for (let j in this.model.licenses[i]) {
                if (!this.model.licenses[i][j].valid) {
                    return false;
                }
            }
        }

        return true;
    }

    removeLicense(i) {
        this.model.licenses.splice(i, 1);
    }

    checkPinOrZipCode() {
        let US_ZIP_SIZE = 5,
            INDIA_ZIP_SIZE = 6;

        return (control: AbstractControl) => {
            if (control.value) {
                if (this.countryCode == "+91") {
                    return control.value.length == INDIA_ZIP_SIZE ? null: { custom: FormValidationErrorMessages.indiaPin };
                }
                else {
                    return control.value.length == US_ZIP_SIZE ? null: { custom: FormValidationErrorMessages.usPin };
                }
            }
        };
    }
}
