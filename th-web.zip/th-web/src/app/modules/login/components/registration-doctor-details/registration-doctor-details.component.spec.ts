import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationDoctorDetailsComponent } from './registration-doctor-details.component';

describe('RegistrationDoctorDetailsComponent', () => {
  let component: RegistrationDoctorDetailsComponent;
  let fixture: ComponentFixture<RegistrationDoctorDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationDoctorDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationDoctorDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
