import {Component, OnInit, Output, EventEmitter, OnDestroy, ViewEncapsulation} from '@angular/core';
import {FormControl, Validators, AbstractControl} from '@angular/forms';

import * as $ from 'jquery';
import {map, first} from "rxjs/internal/operators";
import {Store} from "@ngrx/store";

import {GetConfig} from "../../store/selectors/registration.selector";
import {ToastrService} from "../../../../core/services/toastr.service";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {RegistrationHelperService} from "../../services/registration-helper.service";
import {DoctorService} from "../../../../core/services/doctor.service";
import {SessionUpdate} from "../../../../core/store/actions/session.action";
import { RegexConstants } from '../../../../core/config/regex';
import {PasswordValidator} from "../../../../shared/validators/password.validator";

@Component({
    selector: 'app-registration-credentails',
    templateUrl: 'registration-credentails.component.html',
    styleUrls: ['registration-credentails.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class RegistrationCredentailsComponent implements OnInit {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    private model;
    private loading;
    public RegexConstants;

    constructor(private store: Store<{}>, private toastr: ToastrService, private payloadService: RegistrationHelperService, private doctorService: DoctorService) {
        this.model = {
            password: new FormControl('', [
                Validators.required,
                PasswordValidator
            ]),
        }

        this.RegexConstants = RegexConstants;
    }

    ngOnInit() {
    }

    isValid() {
        for (let i in this.model) {
            if (!this.model[i].valid) {
                return false;
            }
        }

        return true;
    }

    onFinish() {
        this.store.select(GetConfig)
            .pipe(first())
            .subscribe(config => {
                if (config.role == "DOCTOR/EXTENDER") {
                    this.saveUser("BUSER");
                }
                else if (config.role == "PATIENT") {
                    this.saveUser("USER");
                }
                else {
                    this.saveUser("medical_assistant");
                }
            });
    }

    saveUser(role) {
        return this.payloadService.getUserSetupPayload(role)
            .pipe(
                first(),
                map(payload => {
                    let data = new FormData();

                    data.append("user_data", JSON.stringify(Object.assign(payload, {password: this.model.password.value})));

                    return data;
                })
            )
            .subscribe((data) => {
                this.loading = true;
                this.doctorService.createUser({}, data)
                    .subscribe((result) => {
                            this.store.dispatch(RegistrationDataUpdate({
                                user_guid: result.data.user_guid
                            }));
                            this.loading = false;
                            this.toastr.success("User has been successfully registered");
                            this.next.emit();
                        },
                        (data) => {
                            this.toastr.error(data.error.message);
                            this.loading = false;
                        });
            });
    }
}
