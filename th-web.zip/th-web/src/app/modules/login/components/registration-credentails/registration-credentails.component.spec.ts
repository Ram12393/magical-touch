import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationCredentailsComponent } from './registration-credentails.component';

describe('RegistrationCredentailsComponent', () => {
  let component: RegistrationCredentailsComponent;
  let fixture: ComponentFixture<RegistrationCredentailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationCredentailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationCredentailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
