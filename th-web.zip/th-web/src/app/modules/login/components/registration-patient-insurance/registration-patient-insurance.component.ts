import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {Store} from "@ngrx/store";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {RegistrationHelperService} from "../../services/registration-helper.service";

@Component({
  selector: 'app-registration-patient-insurance',
  templateUrl: 'registration-patient-insurance.component.html',
  styleUrls: ['registration-patient-insurance.component.scss']
})
export class RegistrationPatientInsuranceComponent implements OnInit {
  @Output() next = new EventEmitter();
  @Output() prev = new EventEmitter();
  public paymentMethod;
  public availablePaymentMethods = ["INSURANCE", "CASH"];
  public loading: boolean;

  constructor(private store: Store<{}>, private registrationHelper: RegistrationHelperService) { }

  ngOnInit() {
  }

  isValid() {
    return this.paymentMethod;
  }

  selectPayment(method) {
    let consent = true;

    if (method == "CASH") {
      consent = confirm("You will be responsible for any copays/deductible/coinsurance resulting from any interactions with your doctor");
    }

    if (consent) {
      this.paymentMethod = method;
    }
  }

  onNext() {
    this.store.dispatch(RegistrationDataUpdate({
      insurance_type: this.paymentMethod,
      certificates: {}
    }));

    if (this.paymentMethod == "CASH") {
      this.loading = true;
      this.registrationHelper.updateAssistantOrPatient("PATIENT")
          .subscribe(data => {
                this.loading = false;
                this.next.emit()
              },
              (error) => {
                this.loading = false;
              });
    }
    else {
      this.next.emit();
    }
  };
}
