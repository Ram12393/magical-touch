import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationPatientInsuranceComponent } from './registration-patient-insurance.component';

describe('RegistrationPatientInsuranceComponent', () => {
  let component: RegistrationPatientInsuranceComponent;
  let fixture: ComponentFixture<RegistrationPatientInsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationPatientInsuranceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationPatientInsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
