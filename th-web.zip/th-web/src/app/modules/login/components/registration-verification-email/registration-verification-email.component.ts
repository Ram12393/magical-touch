import {Component, OnInit, Output, EventEmitter} from '@angular/core';

import { Store } from "@ngrx/store";
import {map, first} from "rxjs/internal/operators";

import {GetCredentials, GetConfig} from "../../store/selectors/registration.selector";
import {LoginService} from "../../services/login.service";
import {ToastrService} from "../../../../core/services/toastr.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-registration-verification-email',
  templateUrl: 'registration-verification-email.component.html',
  styleUrls: ['registration-verification-email.component.scss']
})
export class RegistrationVerificationEmailComponent implements OnInit {
  @Output() next = new EventEmitter();
  public email$;
  public loading: boolean = false;
  public role;

  constructor(private store: Store<{}>, private loginService: LoginService, private toastr: ToastrService,
    private router: Router) {
    this.email$ = this.store.select(GetCredentials)
        .pipe(
            map(config => config.email)
        );
    this.store.select(GetConfig)
        .pipe(first())
        .subscribe((config) => {
            this.role = config.role;
        })
  }

  ngOnInit() {
  }

  resend() {
    this.loading = true;
    this.loginService.resendEmailVerificationLink()
        .subscribe(() => {
            this.loading = false;
          },
            () => {
              this.loading = false;
            });
  }

  onNext() {
      if (this.role ==  "DOCTOR/EXTENDER") {
          this.loading = true;
          this.loginService.whoAmI({})
              .subscribe((user) => {
                  if (user.status == "ONBOARDING_PENDING") {
                      this.router.navigate(["/onboarding"]);
                  }
                  else {
                      this.router.navigate(["/patients"]);
                  }
              });
      }
      else {
          this.router.navigate(["/patients"]);
      }
  }

}
