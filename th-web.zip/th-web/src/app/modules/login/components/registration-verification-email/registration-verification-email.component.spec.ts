import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationVerificationEmailComponent } from './registration-verification-email.component';

describe('RegistrationVerificationEmailComponent', () => {
  let component: RegistrationVerificationEmailComponent;
  let fixture: ComponentFixture<RegistrationVerificationEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationVerificationEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationVerificationEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
