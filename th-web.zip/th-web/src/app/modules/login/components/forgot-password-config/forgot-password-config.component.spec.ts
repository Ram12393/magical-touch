import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordConfigComponent } from './forgot-password-config.component';

describe('ForgotPasswordConfigComponent', () => {
  let component: ForgotPasswordConfigComponent;
  let fixture: ComponentFixture<ForgotPasswordConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotPasswordConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotPasswordConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
