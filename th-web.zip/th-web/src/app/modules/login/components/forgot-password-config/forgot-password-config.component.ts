import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {Store} from "@ngrx/store";
import {ForgotPasswordDataUpdate, ForgotPasswordDataReset} from "../../store/actions/forgot-password.actions";
import {SettingsUpdate} from "../../../../core/store/actions/settings.action";

@Component({
  selector: 'app-forgot-password-config',
  templateUrl: 'forgot-password-config.component.html',
  styleUrls: ['forgot-password-config.component.scss']
})
export class ForgotPasswordConfigComponent implements OnInit {
  @Output() next = new EventEmitter();

  constructor(private store: Store<{}>) {
    this.store.dispatch(ForgotPasswordDataReset({}));
  }

  ngOnInit() {
  }

  setView(type) {
    this.store.dispatch(ForgotPasswordDataUpdate({
        app_type: type
      }));

    this.store.dispatch(SettingsUpdate({"view": type == "patient" ? "PATIENT" : "DOCTOR"}));

    this.next.emit();
  }

}
