import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {Store} from "@ngrx/store";

import {ForgotPasswordDataUpdate, ForgotPasswordDataReset} from "../../store/actions/forgot-password.actions";

@Component({
  selector: 'app-forgot-password-otp',
  templateUrl: './forgot-password-otp.component.html',
  styleUrls: ['./forgot-password-otp.component.scss']
})
export class ForgotPasswordOtpComponent implements OnInit {
  @Output() next = new EventEmitter();
  public model;

  constructor(public store: Store<{}>) {
  }

  ngOnInit() {
  }

  onNext(code) {
    this.store.dispatch(ForgotPasswordDataUpdate({
      otp: code
    }));

    this.next.emit();
  }
}
