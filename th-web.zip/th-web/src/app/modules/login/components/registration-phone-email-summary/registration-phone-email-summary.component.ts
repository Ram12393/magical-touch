import {Component, OnInit, Output, EventEmitter, OnDestroy} from '@angular/core';
import {Store} from "@ngrx/store";
import {Credentials} from "../../store/models/registration.model";
import {GetCredentials} from "../../store/selectors/registration.selector";

@Component({
    selector: 'app-registration-phone-email-summary',
    templateUrl: 'registration-phone-email-summary.component.html',
    styleUrls: ['registration-phone-email-summary.component.scss']
})
export class RegistrationPhoneEmailSummaryComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    public phone;
    public email;
    public credentialsSubscription$;

    constructor(private store: Store<{}>) {
        this.credentialsSubscription$ = this.store.select(GetCredentials)
            .subscribe((credentials: Credentials) => {
                this.phone = credentials.country_code + credentials.phone;
                this.email = credentials.email;
            });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.credentialsSubscription$.unsubscribe();
    }
}
