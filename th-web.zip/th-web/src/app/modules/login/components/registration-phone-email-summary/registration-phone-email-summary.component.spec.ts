import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationPhoneEmailSummaryComponent } from './registration-phone-email-summary.component';

describe('RegistrationPhoneEmailSummaryComponent', () => {
  let component: RegistrationPhoneEmailSummaryComponent;
  let fixture: ComponentFixture<RegistrationPhoneEmailSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationPhoneEmailSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationPhoneEmailSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
