import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {Store} from "@ngrx/store";

import {PatternValidator} from "../../../../shared/validators/pattern.validator";
import {RegexConstants} from "../../../../core/config/regex";
import {FormValidationErrorMessages} from "../../../../core/config/form-validation-error-messages";
import {ForgotPasswordDataUpdate, ForgotPasswordDataReset} from "../../store/actions/forgot-password.actions";
import {EmailAvailabilityValidator} from "../../../../shared/validators/email-availability.validator.async";
import {LoginService} from "../../services/login.service";
import {ToastrService} from "../../../../core/services/toastr.service";

@Component({
    selector: 'app-forgot-password-email',
    templateUrl: 'forgot-password-email.component.html',
    styleUrls: ['forgot-password-email.component.scss']
})
export class ForgotPasswordEmailComponent implements OnInit {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    public model;
    public loading = false;

    constructor(public store: Store<{}>, public loginService: LoginService, private toastr: ToastrService) {
        this.model = {
            email: new FormControl('', [
                    Validators.required,
                    PatternValidator(RegexConstants.email, FormValidationErrorMessages.email)
                ],
                [
                    EmailAvailabilityValidator(loginService, (data: {available: boolean}) => {
                        return !data.available ? null : {custom: "Email id is not registered."};
                    })
                ])
        };
    }

    ngOnInit() {
    }

    isValid() {
        return this.model.email.valid;
    }

    onNext() {
        if (!this.isValid()) {
            return;
        }

        this.store.dispatch(ForgotPasswordDataUpdate({
            email: this.model.email.value
        }));

        this.loading = true;

        this.loginService.generateOtp({}, {
                email: this.model.email.value
            })
            .subscribe(() => {
                    this.next.emit();
                    this.loading = false;
                },
                (data) => {
                    this.toastr.error(data.error.message);
                    this.loading = false;
                });
    }
}
