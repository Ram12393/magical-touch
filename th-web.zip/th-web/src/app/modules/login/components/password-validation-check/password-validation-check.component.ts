import { Component, OnInit, Input } from '@angular/core';

import { RegexConstants } from '../../../../core/config/regex';

@Component({
  selector: 'app-password-validation-check',
  templateUrl: 'password-validation-check.component.html',
  styleUrls: ['password-validation-check.component.scss']
})
export class PasswordValidationCheckComponent implements OnInit {
  @Input() password;
  public showPasswordRequirements = false;
  public RegexConstants = RegexConstants;

  constructor() { }

  ngOnInit() {
  }

}
