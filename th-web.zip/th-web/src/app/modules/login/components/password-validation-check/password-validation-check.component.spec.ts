import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordValidationCheckComponent } from './password-validation-check.component';

describe('PasswordValidationCheckComponent', () => {
  let component: PasswordValidationCheckComponent;
  let fixture: ComponentFixture<PasswordValidationCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordValidationCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordValidationCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
