import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordNewConfirmPasswordComponent } from './forgot-password-new-confirm-password.component';

describe('ForgotPasswordNewConfirmPasswordComponent', () => {
  let component: ForgotPasswordNewConfirmPasswordComponent;
  let fixture: ComponentFixture<ForgotPasswordNewConfirmPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotPasswordNewConfirmPasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotPasswordNewConfirmPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
