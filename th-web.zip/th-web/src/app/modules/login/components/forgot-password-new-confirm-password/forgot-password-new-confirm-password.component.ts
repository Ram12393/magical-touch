    import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, Validators, AbstractControl} from '@angular/forms';

import {Store} from "@ngrx/store";
import * as $ from 'jquery';

import {GetForgotPasswordData} from "../../store/selectors/forgot-password.selector";
import {first, map} from 'rxjs/internal/operators';
    import {LoginService} from "../../services/login.service";
    import {ToastrService} from "../../../../core/services/toastr.service";
    import {Router} from "@angular/router";

    @Component({
    selector: 'app-forgot-password-new-confirm-password',
    templateUrl: 'forgot-password-new-confirm-password.component.html',
    styleUrls: ['forgot-password-new-confirm-password.component.scss']
})

export class ForgotPasswordNewConfirmPasswordComponent implements OnInit {
    @Output() prev = new EventEmitter();
    @Output() retry = new EventEmitter();
    public model;
    public loading;

    constructor(private store: Store<{}>, private loginService: LoginService, private toastr: ToastrService, private router: Router) {
        this.model = {
            confirmPassword: new FormControl('', [
                    Validators.required
                ],
                [
                    (control: AbstractControl) => {
                        return this.store.select(GetForgotPasswordData)
                            .pipe(
                                first(),
                                map((data) => {
                                    return data.password != control.value ? {custom: "Passwords do not match"} : null;
                                })
                            )
                    }
                ])
        }
    }

    ngOnInit() {
    }

    isValid() {
        return this.model.confirmPassword.valid;
    }

    onFinish() {
        if (!this.isValid()) {
            return;
        }

        this.store.select(GetForgotPasswordData)
            .pipe(first())
            .subscribe((data) => {
                this.loading = true;
                this.loginService.resetPassword({}, $.extend({}, data, {
                        confirm_password: this.model.confirmPassword.value
                    }))
                    .subscribe((data) => {
                            if (data.success) {
                                this.toastr.success("Success Remember to use your new password when logging in the next time around.");
                                this.router.navigateByUrl('/login');
                            }
                            this.loading = false;
                        },
                        (data) => {
                            this.toastr.confirm("Password reset failed! Authorization code does not match.", {
                                    primaryButton: "retry",
                                    secondButton: "cancel"
                                })
                                .subscribe((retry: boolean) => {
                                    if (retry) {
                                        this.retry.emit();
                                    } else {
                                        this.router.navigateByUrl('/login');
                                    }
                                });
                        });
            });
    }
}
