import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Store } from "@ngrx/store";

import { GetSettings } from '../../../../core/store/selectors/settings.selector';
import { SettingsUpdate } from '../../../../core/store/actions/settings.action';
import {RegistrationDataUpdate, RegistrationDataReset} from "../../store/actions/registration.actions";

@Component({
  selector: 'app-registration-config-selection',
  templateUrl: 'registration-config-selection.component.html',
  styleUrls: ['registration-config-selection.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RegistrationConfigSelectionComponent implements OnInit, OnDestroy {
  @Input() role: FormControl;
  @Output() next = new EventEmitter();
  public availableRoles: string[];
  public availableViews: string[];
  public selectedView;
  public settings = {};
  private configSubscription$;

  constructor(public store: Store<{}>) {
    this.availableRoles = ['DOCTOR/EXTENDER', 'OFFICE ASSISTANT'];
    this.availableViews = ['DOCTOR', 'PATIENT'];

    this.configSubscription$ = this.store.select(GetSettings)
        .subscribe((settings) => {
          this.settings = settings;
        });

    this.store.dispatch(RegistrationDataReset({}));
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.configSubscription$.unsubscribe();
  }
  
  setView(view) {
    this.selectedView = view;


    if (view == "PATIENT") {
      this.store.dispatch(SettingsUpdate({"view": 'PATIENT'}));
      this.store.dispatch(RegistrationDataUpdate({config: {role: "PATIENT", type: "PATIENT"}}));
      this.next.emit({role: "PATIENT", type: "PATIENT"});
    }
    else {
      this.store.dispatch(SettingsUpdate({"view": 'DOCTOR'}));
    }

  }

  setRole(role) {
    this.next.emit({role: role, type: this.selectedView});
    this.store.dispatch(RegistrationDataUpdate({config: {role: role, type: this.selectedView}}));
  }

}
