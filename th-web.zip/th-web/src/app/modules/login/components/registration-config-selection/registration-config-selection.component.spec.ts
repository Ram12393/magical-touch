import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationRoleSelectionComponent } from './registration-doctor-role-selection.component';

describe('RegistrationRoleSelectionComponent', () => {
  let component: RegistrationRoleSelectionComponent;
  let fixture: ComponentFixture<RegistrationRoleSelectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationRoleSelectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationRoleSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
