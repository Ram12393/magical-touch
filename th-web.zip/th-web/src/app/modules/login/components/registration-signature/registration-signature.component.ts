import {Component, OnInit, ElementRef, Output, EventEmitter, OnDestroy} from '@angular/core';

import {Store} from "@ngrx/store";

import * as $ from 'jquery';
import SignaturePad from 'signature_pad';
import {GetSignature} from "../../store/selectors/registration.selector";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {first, map} from "rxjs/internal/operators";
import {DoctorService} from "../../../../core/services/doctor.service";
import {RegistrationHelperService} from "../../services/registration-helper.service";
import {SessionUpdate} from "../../../../core/store/actions/session.action";
import {ToastrService} from "../../../../core/services/toastr.service";

@Component({
    selector: 'app-registration-signature',
    templateUrl: 'registration-signature.component.html',
    styleUrls: ['registration-signature.component.scss']
})
export class RegistrationSignatureComponent implements OnInit, OnDestroy {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    private signaturePad;
    private signatureSubscription$;
    public showBAADocument = true;
    public loading: boolean = false;

    constructor(private ele: ElementRef, private store: Store<{}>, private doctorService: DoctorService, private payloadService: RegistrationHelperService,
                private toastr: ToastrService) {
    }

    ngOnInit() {
        let canvas = $(this.ele.nativeElement).find("canvas")[0];

        var ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        canvas.getContext("2d").scale(ratio, ratio);


        this.signaturePad = new SignaturePad(canvas, {
            maxWidth: 1
        });

        this.signatureSubscription$ = this.store.select(GetSignature)
            .subscribe(signature => {
                if (signature) {
                    this.signaturePad.fromDataURL(signature);
                    this.showBAADocument = false;
                }
            });
    }

    ngOnDestroy() {
        this.signatureSubscription$.unsubscribe();
    }

    isValid() {
        return !this.signaturePad._isEmpty;
    }

    updateSignature() {
        this.store.dispatch(RegistrationDataUpdate({
            signature: this.signaturePad.toDataURL()
        }));
    }

    onFinish() {
        this.loading = true;

        this.payloadService.updateDoctorProfile()
            .subscribe((data) => {
                    this.loading = false;
                    this.next.emit();
                },
                (data) => {
                    this.toastr.error(data.error ? data.error.message : '');
                    this.loading = false;
                });

    }
}
