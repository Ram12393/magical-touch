import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationSignatureComponent } from './registration-signature.component';

describe('RegistrationSignatureComponent', () => {
  let component: RegistrationSignatureComponent;
  let fixture: ComponentFixture<RegistrationSignatureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationSignatureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationSignatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
