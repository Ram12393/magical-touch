import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormControl } from '@angular/forms';

import {DoctorService} from '../../../../core/services/doctor.service';
import {Store} from "@ngrx/store";
import {RegistrationDataUpdate} from "../../store/actions/registration.actions";
import {GetSearchName} from "../../store/selectors/registration.selector";
import {RegistrationHelperService} from "../../services/registration-helper.service";

@Component({
    selector: 'app-registration-doctor-registry-choose-profile',
    templateUrl: 'registration-doctor-registry-choose-profile.component.html',
    styleUrls: ['registration-doctor-registry-choose-profile.component.scss']
})
export class RegistrationDoctorRegistryChooseProfileComponent implements OnInit {
    @Output() next = new EventEmitter();
    @Output() prev = new EventEmitter();
    @Output() skipProfileSelection = new EventEmitter();
    public profiles: any[] = [];
    public total_count: number = 0;
    public loading: boolean = false;
    private profilesRequestConfig: any;
    public name;

    constructor(private doctorService: DoctorService, private store: Store<{}>, private registrationPayloadService: RegistrationHelperService) {
        this.resetProfilesRequestConfig();
        this.store.select(GetSearchName)
            .subscribe((searchName) => {
                this.name = searchName;
            });
    }

    ngOnInit() {
        this.getDoctorProfiles();
    }

    getDoctorProfiles() {
        this.loading = true;
        this.doctorService.getDoctorDetails({
                params: {
                    name: this.name,
                    page: ++this.profilesRequestConfig.page,
                    page_size: this.profilesRequestConfig.page_size
                }
            })
            .subscribe((result) => {
                this.profiles.push.apply(this.profiles, result.data);
                this.total_count = result.total_count;
                this.loading = false;
            });
    }

    resetProfilesRequestConfig() {
        this.profiles = [];
        this.profilesRequestConfig = {
            page: 0,
            page_size: 10
        };
    }

    selectDoctorProfile(detail) {
        this.registrationPayloadService.updateUserProfile(detail);
    }
}
