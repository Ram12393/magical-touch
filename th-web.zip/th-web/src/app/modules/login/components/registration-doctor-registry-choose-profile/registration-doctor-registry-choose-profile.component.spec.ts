import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationDoctorRegistryChooseProfileComponent } from './registration-doctor-registry-choose-profile.component';

describe('RegistrationDoctorRegistryChooseProfileComponent', () => {
  let component: RegistrationDoctorRegistryChooseProfileComponent;
  let fixture: ComponentFixture<RegistrationDoctorRegistryChooseProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationDoctorRegistryChooseProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationDoctorRegistryChooseProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
