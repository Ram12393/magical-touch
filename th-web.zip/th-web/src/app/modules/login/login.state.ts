import { RegistrationDataReducer } from './store/reducers/registration.reducer';
import {ForgotPasswordDataReducer} from "./store/reducers/forgot-password.reducer";

export const State = {
    registrationData: RegistrationDataReducer,
    forgotPasswordData: ForgotPasswordDataReducer
}