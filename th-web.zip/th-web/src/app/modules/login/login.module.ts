import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StoreModule } from '@ngrx/store';

import { LoginRouteRoutingModule } from './login-routing.module';

import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { SigninComponent } from './components/signin/signin.component';

import { BlocksModule } from '../../blocks/blocks.module';
import { DirectiveModule } from '../../shared/directives/directive.module';
import { PipeModule } from '../../shared/pipes/pipe.module';

import { RegistrationConfigSelectionComponent } from './components/registration-config-selection/registration-config-selection.component';
import { RegistrationDoctorRegistryLookupComponent } from './components/registration-doctor-registry-lookup/registration-doctor-registry-lookup.component';
import { RegistrationDoctorDetailsComponent } from './components/registration-doctor-details/registration-doctor-details.component';
import { RegistrationCertificateComponent } from './components/registration-certificate/registration-certificate.component';
import { RegistrationCredentailsComponent } from './components/registration-credentails/registration-credentails.component';
import { RegistrationVerificationComponent } from './components/registration-verification/registration-verification.component';
import { RegistrationTermsAndConditionComponent } from './components/registration-terms-and-condition/registration-terms-and-condition.component';
import { RegistrationDoctorRegistryChooseProfileComponent } from './components/registration-doctor-registry-choose-profile/registration-doctor-registry-choose-profile.component';
import { RegistrationDoctorRegistryChoosePractiseComponent } from './components/registration-doctor-registry-choose-practise/registration-doctor-registry-choose-practise.component';
import { RegistrationVerificationEmailComponent } from './components/registration-verification-email/registration-verification-email.component';
import { RegistrationAssistantDetailsComponent } from './components/registration-assistant-details/registration-assistant-details.component';
import { RegistrationEmailLookupComponent } from './components/registration-email-lookup/registration-email-lookup.component';
import { RegistrationPatientDetailsComponent } from './components/registration-patient-details/registration-patient-details.component';
import { RegistrationPhoneLookupComponent } from './components/registration-phone-lookup/registration-phone-lookup.component';
import { RegistrationPhoneEmailSummaryComponent } from './components/registration-phone-email-summary/registration-phone-email-summary.component';
import { RegistrationSignatureComponent } from './components/registration-signature/registration-signature.component';
import { RegistrationPatientInsuranceComponent } from './components/registration-patient-insurance/registration-patient-insurance.component';
import { ForgotPasswordEmailComponent } from './components/forgot-password-email/forgot-password-email.component';
import { ForgotPasswordNewPasswordComponent } from './components/forgot-password-new-password/forgot-password-new-password.component';
import { ForgotPasswordNewConfirmPasswordComponent } from './components/forgot-password-new-confirm-password/forgot-password-new-confirm-password.component';
import { PasswordValidationCheckComponent } from './components/password-validation-check/password-validation-check.component';
import { ForgotPasswordOtpComponent } from './components/forgot-password-otp/forgot-password-otp.component';
import { ForgotPasswordConfigComponent } from './components/forgot-password-config/forgot-password-config.component';
import { OnboardingComponent } from './pages/onboarding/onboarding.component';

import { State } from './login.state';

@NgModule({
  declarations: [
    LoginComponent,
    RegistrationComponent,
    SigninComponent,
    ForgotPasswordComponent,
    RegistrationConfigSelectionComponent,
    RegistrationDoctorRegistryLookupComponent,
    RegistrationDoctorDetailsComponent,
    RegistrationCertificateComponent,
    RegistrationCredentailsComponent,
    RegistrationVerificationComponent,
    RegistrationTermsAndConditionComponent,
    RegistrationDoctorRegistryChooseProfileComponent,
    RegistrationDoctorRegistryChoosePractiseComponent,
    RegistrationVerificationEmailComponent,
    RegistrationAssistantDetailsComponent,
    RegistrationEmailLookupComponent,
    RegistrationPatientDetailsComponent,
    RegistrationPhoneLookupComponent,
    RegistrationPhoneEmailSummaryComponent,
    RegistrationSignatureComponent,
    RegistrationPatientInsuranceComponent,
    ForgotPasswordEmailComponent,
    ForgotPasswordNewPasswordComponent,
    ForgotPasswordNewConfirmPasswordComponent,
    PasswordValidationCheckComponent,
    ForgotPasswordOtpComponent,
    ForgotPasswordConfigComponent,
    OnboardingComponent
  ],
  imports: [
    CommonModule,
    BlocksModule,
    DirectiveModule,
    LoginRouteRoutingModule,
    PipeModule,
    StoreModule.forFeature('login', State)
  ]
})
export class LoginModule { }
