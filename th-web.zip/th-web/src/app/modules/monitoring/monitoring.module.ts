import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MonitoringRoutingModule } from './monitoring-routing.module';
import { VitalsComponent } from './pages/vitals/vitals.component';
import { InfoComponent } from './pages/info/info.component';
import { MonitoringComponent } from './pages/monitoring/monitoring.component';
import { BlocksModule } from 'src/app/blocks/blocks.module';
import { SharedComponentsModule } from 'src/app/shared/components/shared-components.module';
import { ListComponent } from './pages/list/list.component';
import { AccordionComponent } from './component/accordion.component';
import { AccordionGroupComponent } from './component/accordion-group.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  declarations: [
    VitalsComponent,
    InfoComponent,
    MonitoringComponent,
    ListComponent,
    AccordionComponent,
    AccordionGroupComponent
  ],
  imports: [
    CommonModule,
    BlocksModule,
    SharedComponentsModule,
    MonitoringRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    SharedComponentsModule,
    InfiniteScrollModule
  ]
})
export class MonitoringModule { }

