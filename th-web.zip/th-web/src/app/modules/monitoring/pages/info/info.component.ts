import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { DataService } from 'src/app/core/services/data.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {
  public info: any;
  public guid: string;
  public showModal = false;
  public settings: {};
  public loading = false;
  public pdfLoading = false;
  constructor(
    private patientService: PatientService,
    private activateroute: ActivatedRoute,
    private dataService: DataService,
    private store: Store<{}>) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });

    this.dataService.getPatientID().subscribe(res => {
      this.loading = true;
      this.guid = res;
      this.getDetails(res);
    });
  }
  ngOnInit() {
  }
  getDetails(guid) {
    if (guid) {
      this.patientService.getPatientInfo({
        params: {
          filter_user_guid_in: guid
        }
      })
        .subscribe((result) => {
          this.info = result[0];
          this.loading = false;
        });
    }
  }
  disconnect() {
    let parameter: any;
    if (this.settings['view'] === 'DOCTOR') {
      parameter = {
        params: {
          user_guid: this.guid
        }
      };
    } else {
      parameter = {
        params: {
          doctor_guid: this.guid.split('&')[1],
          user_guid: this.guid.split('&')[0]
        }
      };
    }
    this.patientService.disconnet_patient(parameter)
      .subscribe((result) => {
        if (result.success) {
          this.showModal = false;
        }
      });
  }

  print() {
    this.pdfLoading = true;
    this.store.select(GetSettings)
    .subscribe(settings => {
      this.settings = settings;
    });

    const filterParams = !this.settings['start_date'] ?  {
      filter: 'last_week'
    } : {
      start_date: this.settings['start_date'],
      end_date: this.settings['end_date']
    };
    this.patientService.download_pdf({params: {
      download_summary: true,
      user_guid: this.guid,
      ...filterParams
    }}).subscribe(res => {
      this.pdfLoading = false;
      window.open(res.result.summary, '_blank');
    });
  }

  ngOnDestroy() {}
} 
