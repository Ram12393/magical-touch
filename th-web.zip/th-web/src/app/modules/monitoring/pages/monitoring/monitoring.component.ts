import { Component, OnInit, HostListener } from '@angular/core';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { DoctorService } from 'src/app/core/services/doctor.service';
import { Store } from '@ngrx/store';
import { PatientService } from 'src/app/core/services/patient.service';

@Component({
  selector: 'app-monitoring',
  templateUrl: './monitoring.component.html',
  styleUrls: ['./monitoring.component.scss']
})
export class MonitoringComponent implements OnInit {
  public dropdown_visibility = false;
  public doctor_list: any;
  public guid_id: string;
  public show_doctors = false;
  public current_doctor = 'All Doctors';
  public settings = {};

  constructor(
    public doctorService: DoctorService,
    public patientService: PatientService,
    private store: Store<{}>) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }

  ngOnInit() {
    if (this.settings['view'] == 'MA') {
      this.show_doctors = true;
      this.patientService.getVitalInfo({
        params: {
          filter: 'last_week'
        }
      }).subscribe(res => {
        console.log('######', res);
        this.doctor_list = res;
        this.loadPatient(res[0].user_guid, res[0].first_name, res[0].last_name);
      });
    }

  }
  loadPatient(user_guid: string, fname: string, lname: string) {
    this.current_doctor = 'Dr. ' + fname + ' ' + lname;
    this.guid_id = user_guid;
    this.dropdown_visibility = false;
  }
}
