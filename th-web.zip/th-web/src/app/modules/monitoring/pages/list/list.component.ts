import { Component, OnInit, Input, HostListener } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { DoctorService } from 'src/app/core/services/doctor.service';
import { PatientService } from 'src/app/core/services/patient.service';
import { FormControl, Validators } from '@angular/forms';
import { DataService } from 'src/app/core/services/data.service';
import { SettingsUpdate } from 'src/app/core/store/actions/settings.action';
import { environment } from 'src/environments/environment';
import * as $ from 'jquery';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  public patient_Details: any;
  public profilesRequestConfig: any;
  public guid: any;
  public loadinglist = false;
  public settings = {};
  public filter = false;
  public filterDropdown = false;
  public showCalender = false;
  public filterObj;
  public vitalsEmptyStateMessage: string;
  public months = ['Jan', 'Feb', 'Mar', 'Ap', 'May', 'Jun',
    'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  public monthNames =
    ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  public filter_message: string;
  public selectedFilters: any;
  @Input()
  set doctor_guid(message: string) {
    this.guid = message;
    this.patientList(this.guid);
  }
  constructor(
    private patientService: PatientService,
    private router: Router,
    private dataService: DataService,
    private store: Store<{}>) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
    this.resetProfilesRequestConfig();
  }
  ngOnInit() {
    this.filter_message = 'Last Week';
    this.selectedFilters = 'Last Week';
    const currentMonth = new Date().getMonth();
    this.filterObj = {
      last_week: 'Last Week',
      current_month: this.monthNames[currentMonth],
      last_month: this.monthNames[currentMonth - 1],
      custom_range: 'Custom Range'
    };
  }
  patientList(guid: string) {
    this.loadinglist = true;
    if (this.settings.view === 'DOCTOR') {
      this.patientService.patientVitals(
        {
          params: {
            filter: 'last_week',
            page: 1, // ++this.profilesRequestConfig.page,
            page_size: environment.perPage,
            paginate: true,
          }
        }
      )
        .subscribe((result) => {
          this.loadinglist = false;
          this.patient_Details = result.result;
          if (this.patient_Details.length > 0) {
            this.dataService.sendPatientID(this.patient_Details[0].user_guid);
            this.fetch_info(this.patient_Details[0].user_guid);
            return;
          }
          this.vitalsEmptyStateMessage = ' There are no vitals measured in the last week';
        });
    }
  }
  fetch_info(user_guid: any) {
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.patient_Details.length; i++) {
      this.patient_Details[i].active = false;
      if (this.patient_Details[i].user_guid === user_guid) {
        this.patient_Details[i].active = true;
      }
    }
    this.router.navigate(['monitoring']);
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: environment.perPage
    };
  }


  selectedPatient(id) {
    this.dataService.sendPatientID(id);
  }

  openFilters(e) {
    this.filter = !this.filter;
  }
  closeFilterModel(e) {
    this.openFilters(e);
    this.filter_message = e.filter ? e.filter :
      `${new Date(e.start_date).getDate()} ${this.months[new Date(e.start_date).getMonth()]},${new Date(e.start_date).getFullYear()} -
      ${new Date(e.end_date).getDate()} ${this.months[new Date(e.end_date).getMonth()]}, ${new Date(e.end_date).getFullYear()} `;
    this.loadinglist = true;
    const filterParams = !e.start_date ? {
      filter: 'last_week'
    } : {
        start_date: e.start_date,
        end_date: e.end_date
      };
    this.patientService.patientVitals(
      {
        params: {
          page: 1, // ++this.profilesRequestConfig.page,
          page_size: environment.perPage,
          paginate: true,
          ...filterParams
        }
      }
    )
      .subscribe((result) => {
        this.loadinglist = false;
        this.patient_Details = result.result;
        if (this.patient_Details.length > 0) {
          this.dataService.sendPatientID(this.patient_Details[0].user_guid);
          this.fetch_info(this.patient_Details[0].user_guid);
          return;
        }
        this.vitalsEmptyStateMessage = e.start_date ? `No Vital Measurements from
                                        ${new Date(e.start_date).getDate()} ${this.months[new Date(e.start_date).getMonth()]},
                                        ${new Date(e.start_date).getFullYear()}
                                        to ${new Date(e.end_date).getDate()} ${this.months[new Date(e.end_date).getMonth()]},
                                        ${new Date(e.end_date).getFullYear()}.` : 'There are no vitals measured in the last week';
      });
    this.loadinglist = false;
  }

  /**
   * close filter on esc button
   */
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (this.filter) {
      this.filter = false;
    }
  }
  filters() {
    this.filterDropdown = !this.filterDropdown;
  }
  onSelectFilters(filter) {
    this.selectedFilters = filter;
    this.filter_message = filter;
    this.filterDropdown = false;
    const date = new Date();
    if (filter === this.filterObj.current_month) {
      const startDate = new Date(date.getFullYear(), date.getMonth(), 1).toLocaleDateString();
      const endDate = new Date().toLocaleDateString();
      const filterParams = {
        start_date: startDate,
        end_date: endDate
      };
      this.getPatientList(filterParams);
      this.store.dispatch(SettingsUpdate({ start_date: startDate, end_date: endDate }));
      this.filter_message =
        `${new Date(startDate).getDate()} ${this.months[new Date(startDate).getMonth()]},${new Date(startDate).getFullYear()} -
      ${new Date(endDate).getDate()} ${this.months[new Date(endDate).getMonth()]}, ${new Date(endDate).getFullYear()} `;
    }
    if (filter === this.filterObj.last_month) {
      const startDate = new Date(date.getFullYear() -
        (date.getMonth() > 0 ? 0 : 1), (date.getMonth() - 1 + 12) % 12, 1).toLocaleDateString();
      const endDate = new Date(date.getFullYear(), date.getMonth(), 0).toLocaleDateString();
      const filterParams = {
        start_date: startDate,
        end_date: endDate
      };
      this.store.dispatch(SettingsUpdate({ start_date: startDate, end_date: endDate }));
      this.getPatientList(filterParams);
      this.filter_message =
        `${new Date(startDate).getDate()} ${this.months[new Date(startDate).getMonth()]},${new Date(startDate).getFullYear()} -
      ${new Date(endDate).getDate()} ${this.months[new Date(endDate).getMonth()]}, ${new Date(endDate).getFullYear()} `;
    }
    if (filter === this.filterObj.custom_range) {
      this.showCalender = !this.showCalender;
      this.filterDropdown = !this.filterDropdown;

      $(function() {
      $( '.calendar' ).datepicker({
          dateFormat: 'dd/mm/yy',
          firstDay: 1
        });

      // $(document).on('click', '.date-picker .input', function(e) {
      //     const $me = $(this),
      //         $parent = $me.parents('.date-picker');
      //     $parent.toggleClass('open');
      //   });


      // $('.calendar').on('change', function() {
      //     const $me = $(this),
      //         $selected = $me.val(),
      //         $parent = $me.parents('.date-picker');
      //     $parent.find('.result').children('span').html($selected);
      //   });
      });


    }
  }

  getPatientList(filterParams) {
    this.patientService.patientVitals(
      {
        params: {
          page: 1, // ++this.profilesRequestConfig.page,
          page_size: environment.perPage,
          paginate: true,
          filterParams
        }
      }
    )
      .subscribe((result) => {
        this.loadinglist = false;
        this.patient_Details = result.result;
        if (this.patient_Details.length > 0) {
          this.dataService.sendPatientID(this.patient_Details[0].user_guid);
          this.fetch_info(this.patient_Details[0].user_guid);
          return;
        }
        this.vitalsEmptyStateMessage = filterParams.start_date ? `No Vital Measurements from
                                        ${new Date(filterParams.start_date).getDate()} ${this.months[new Date(filterParams.start_date).getMonth()]},
                                        ${new Date(filterParams.start_date).getFullYear()}
                                        to ${new Date(filterParams.end_date).getDate()} ${this.months[new Date(filterParams.end_date).getMonth()]},
                                        ${new Date(filterParams.end_date).getFullYear()}.` : 'There are no vitals measured in the last week';
      });
    this.loadinglist = false;
  }

}
