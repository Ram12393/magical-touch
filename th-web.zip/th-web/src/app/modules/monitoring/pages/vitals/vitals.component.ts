import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { PatientService } from 'src/app/core/services/patient.service';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataService } from 'src/app/core/services/data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-vitals',
  templateUrl: './vitals.component.html',
  styleUrls: ['./vitals.component.scss']
})
export class VitalsComponent implements OnInit {
  public profilesRequestConfig: any;
  public user_guid: string;
  public vitalInformation: any;
  public displayName: string;
  public settings: {};
  public loading = false;
  public vital_summary: any;
  public nextPage: number = 1;
  public prevPage: number = 0;
  public isNext: boolean;
  public isScroll: boolean;
  public isLoading: boolean;
  public months = ['Jan', 'Feb', 'Mar', 'Ap', 'May', 'Jun',
    'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  private vitalEmptyMessage: string;

  @Input() userGuid: string;
  constructor(
    private patientService: PatientService,
    private dataService: DataService,
    private store: Store<{}>) {
    this.resetProfilesRequestConfig();
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });

    this.dataService.getPatientID().subscribe(res => {
      this.userGuid = res;
      this.vitalinfo(res, 1);
    });
  }

  ngOnInit() {
    this.vitalinfo(this.userGuid, 1);
    this.vital_summary = [];
    this.loading = true;
  }

  vitalinfo(id, pageNumber) {
    const filterParams = !this.settings['start_date'] ? {
      filter: 'last_week'
    } : {
        start_date: this.settings['start_date'],
        end_date: this.settings['end_date']
      };
    this.patientService.getVitalInfo({
      params: {
        page: pageNumber, // ++this.profilesRequestConfig.page, // this needs to change,
        page_size: this.profilesRequestConfig.page_size,
        paginate: true,
        user_guid: id,
        ...filterParams
      }
    }).subscribe((res) => {
      this.loading = false;
      this.vitalInformation = res;
      if (res.result.length > 0) {
        res.result = this.addIcons(res.result);
        this.createGroup(res);
        return;
      }
      this.vitalEmptyMessage = this.settings['start_date'] ? ` There are no vitals measured in this
      ${new Date(this.settings['start_date']).getDate()}
      ${this.months[new Date(this.settings['start_date']).getMonth()]}, ${new Date(this.settings['start_date']).getFullYear()}
      to ${new Date(this.settings['end_date']).getDate()} ${this.months[new Date(this.settings['end_date']).getMonth()]},
      ${new Date(this.settings['end_date']).getFullYear()} duration.` : 'There is no vital measured in the last week.';
    });
  }

  addIcons(data) {
    return data.map(el => {
      if (el.display_type === 'Blood Pressure') {
        el.icon = '/assets/images/vitals-icn-bloodpressure.png';
      }
      if (el.display_type === 'Pulse Rate') {
        el.icon = '/assets/images/vitals-icon-vitals.png';
      }
      if (el.display_type === 'Oxygen Saturation') {
        el.icon = '/assets/images/vitals-icn-pulse-oximeter.png';
      }
      if (el.display_type === 'Weight') {
        el.icon = '/assets/images/vitals-icn-weight.png';
      }
      if (el.display_type === 'Blood Sugar') {
        el.icon = '/assets/images/vitals-icn-bloodpressure.png';
      }
      if (el.display_type === 'Temperature') {
        el.icon = '/assets/images/vitals-icn-temperature.png';
      }
      return el;
    });
  }
  createGroup(visitJson: any) {
    const groups = visitJson.result.reduce((groups, game) => {
      const date = game.created_at.split('T')[0];
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(game);
      return groups;
    }, {});
    const tempObj = Object.keys(groups).map((date) => {
      return {
        date,
        visit: groups[date]
      };
    });
    this.vital_summary.push(...tempObj);
    this.isNext = visitJson.next ? true : false;
    this.isScroll = this.isNext ? false : true;
    this.loading = false;
    this.isLoading = false;
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
  onScroll() {
    if (this.nextPage) {
      this.nextPage += 1;
      this.isLoading = true;
      this.vitalinfo(this.userGuid, this.nextPage);
    }
  }
}

