import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'src/app/core/guards/auth.guard';
import { VitalsComponent } from './pages/vitals/vitals.component';
import { MonitoringComponent } from './pages/monitoring/monitoring.component';
import { InfoComponent } from './pages/info/info.component';

const routes: Routes = [
  {
    path: '',
    component: MonitoringComponent,
    canLoad: [AuthGuardService],
    children : [
      {
        path: '',
        component: InfoComponent,
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MonitoringRoutingModule { }
