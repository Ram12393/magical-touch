import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss']
})
export class CardsComponent implements OnInit {
  public data: any;
  @Input()
  set order_data(message: any) {
    this.data = message;
  }
  @Input() userName: string;
  @Output() cardData = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  cardclicked(data:any) {
    data.userName = this.userName;
    this.cardData.emit(data);
  }
}
