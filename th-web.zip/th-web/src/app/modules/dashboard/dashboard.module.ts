import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { InfoComponent } from './pages/info/info.component';
import { ListComponent } from './pages/list/list.component';
import { BlocksModule } from '../../blocks/blocks.module';
import { AboutComponent } from './pages/about/about.component';
import { VitalsComponent } from './pages/vitals/vitals.component';
import { DocumentComponent } from './pages/document/document.component';
import { VisitsComponent } from './pages/visits/visits.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { AccordionGroupComponent } from './component/accordion-group.component';
import { AccordionComponent } from './component/accordion.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { CardsComponent } from './component/cards/cards.component';
import { ViewComponent } from './pages/orders/prescription/view/view.component';
import { CreateComponent } from './pages/orders/prescription/create/create.component';
import { SharedComponentsModule } from '../../shared/components/shared-components.module';
import { PipeModule } from 'src/app/shared/pipes/pipe.module';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    BlocksModule,
    SharedComponentsModule,
    PipeModule
  ],
  declarations: [
    InfoComponent,
    ListComponent,
    AboutComponent,
    VitalsComponent,
    DocumentComponent,
    VisitsComponent,
    OrdersComponent,
    AccordionGroupComponent,
    AccordionComponent,
    DashboardComponent,
    CardsComponent,
    ViewComponent,
    CreateComponent
  ]
})
export class DashboardModule { }
