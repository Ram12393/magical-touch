import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/core/services/patient.service';
import { Router } from '@angular/router';
import { Store } from "@ngrx/store";
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import {GetSession} from "../../../../core/store/selectors/session.selector";

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {
  public profilesRequestConfig: any;
  public orderData;
  public displayName: string;
  public viewprescription: boolean = false;
  public loading: boolean = false;
  public loadingOrders: boolean = false;
  public prescriptionData: any;
  public settings: {};
  public parameter: any;
  public order_data: any;
  public userName: any;
  public guid: any;
  constructor(private patientService: PatientService, private route: Router, private store: Store<{}>) {
    this.resetProfilesRequestConfig();
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }

  ngOnInit() {
    this.store.select(GetSession)
        .subscribe((session) => {
          this.loadingOrders = true;
          this.guid = this.route.url.split("/")[this.route.url.split("/").length - 2];
          if (this.settings["view"] == "DOCTOR") {
            this.parameter = {
              params: {
                user_guid: this.guid,
                page: 1,//++this.profilesRequestConfig.page,
                page_size: this.profilesRequestConfig.page_size,
                paginate: true
              }
            }
          }
          this.patientService.getPatientInfo({
            params: {
              filter_user_guid_in: this.guid,
            }
          })
              .subscribe(res => {
                this.order_data = [
                  { ordername: "Prescriptions", orderval: "prescriptions", active: false },
                  { ordername: "Referrals", orderval: "specialists", active: false },
                  { ordername: "Labs", orderval: "labs", active: false },
                  { ordername: "Radialogies", orderval: "radiology", active: false },
                  { ordername: "Forms", orderval: "forms", active: false },
                  { ordername: "Miscellaneous", orderval: "misc", active: false }]
                this.userName = res[0].first_name + ' ' + res[0].last_name;
                this.loadingOrders = false;
              });
        });
  }

  orderinfo(value: any) {
    this.order_data.forEach(res=>{
      res.active = false;
    })
    value.active = true;
    this.displayName = value.ordername;
    this.loading = true;
    switch (value.orderval) {
      case 'prescriptions':
        this.patientService.getorder_prescription(this.parameter)
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
      case 'labs':
        this.patientService.getorder_labs(this.parameter)
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
      case 'specialists':
        this.patientService.getorder_referrals(this.parameter)
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
      case 'radiology':
        this.patientService.getorder_radiology(this.parameter)
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
      case 'misc':
        this.patientService.getorder_misc(this.parameter)
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
      case 'forms':
        this.patientService.getorder_fomrs({
          params: {
            user_guid: this.guid,
            assignor: true,
            page: 1,//++this.profilesRequestConfig.page,
            page_size: this.profilesRequestConfig.page_size,
            paginate: true
          }
        })
          .subscribe(res => {
            this.orderData = res.result;
            this.loading = false;
          });
        break;
    }
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
  createView(data) {
    if (data.type == 'prescription') {
      console.log(data);
      this.viewprescription = true;
      this.prescriptionData = data;
    }
  }
  close() {
    this.viewprescription = false;
    this.prescriptionData = "";
  }
}
