import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { element } from 'protractor';

@Component({
  selector: 'app-vitals',
  templateUrl: './vitals.component.html',
  styleUrls: ['./vitals.component.scss']
})
export class VitalsComponent implements OnInit {
  public profilesRequestConfig: any;
  public user_guid: string;
  public vitalInformation: any;
  public displayName: string;
  public settings: {};
  public loading = false;
  public vital_data = [
    { vitalname: 'BP & Pulse Rate', vitalval: 'bp\&heartRate', active: false},
    { vitalname: 'Weight', vitalval: 'weight', active: false },
    { vitalname: 'Body Temperature', vitalval: 'temperature', active: false },
    { vitalname: 'Blood Glucose', vitalval: 'gulcose', active: false },
    { vitalname: 'Pulse Oximeter', vitalval: 'pulseOximeter', active: false }
  ];
  constructor(private patientService: PatientService, private route: Router, private store: Store<{}>) {
    this.resetProfilesRequestConfig();
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
    });
  }

  ngOnInit() {
    this.user_guid = this.route.url.split('/')[this.route.url.split('/').length - 2];
  }
  vitalinfo(value: any) {
    this.vital_data.forEach(res => {
      res.active = false;
    });
    value.active = true;
    this.loading = true;
    this.displayName = value.vitalname;

    if (this.settings['view'] === 'DOCTOR') {
      this.user_guid = this.user_guid;
    } else {
      this.user_guid = this.user_guid.split('&')[0];
    }
    this.patientService.getVitalInfo({
      params: {
        page: 1, // ++this.profilesRequestConfig.page, // this needs to change,
        page_size: this.profilesRequestConfig.page_size,
        paginate: true,
        type: value.vitalval,
        user_guid: this.user_guid
      }
    }).subscribe((res) => {
      res.result.forEach(element => {
        if (element.bundle_id === 'com.thealer' || element.bundle_id === 'com.thealer.pro') {
          switch (element.mode) {
            case 'doctor':
              element.captured_by = 'Captured by doctor';
              break;
            case 'patient':
              element.captured_by = 'Captured by patient';
              break;
            case 'automated':
              element.captured_by = 'Captured by device';
          }
        } else {
          element.captured_by = 'Captured via ' + element.display_name;
        }
        console.log('sdsafa');
        this.createGroup(res.result);
      });
    });
  }
  createGroup(vitalJson: any) {
    const groups = vitalJson.reduce((groups, game) => {
      const date = game.date.split('T')[0];
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(game);
      return groups;
    }, {});
    this.vitalInformation = Object.keys(groups).map((date) => {
      return {
        date,
        vitals: groups[date]
      };
    });
    this.loading = false;
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
}
