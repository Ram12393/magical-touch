import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { Router } from '@angular/router';

@Component({
  selector: 'app-visits',
  templateUrl: './visits.component.html',
  styleUrls: ['./visits.component.scss']
})
export class VisitsComponent implements OnInit {
  public profilesRequestConfig: any;
  public visit_data:any;
  public loading: boolean = false;
  public settings = {};
  constructor(private patientService: PatientService,private store: Store<{}>, private route:Router) { 
    this.resetProfilesRequestConfig();
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }

  ngOnInit() {
    this.loading = true;
    let guid = this.route.url.split("/")[this.route.url.split("/").length - 2];
    let parameter;
    if (this.settings["view"] == "DOCTOR") {
      parameter = {
        params: {
          calls: true,
          page: 1,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true,
          user_guid: guid
        }
      }
    } else {
      parameter = {
        params: {
          calls: true,
          page: 1,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true,
          doctor_guid: guid.split("&")[1],
          user_guid: guid.split("&")[0]
        }
      }
    }
    this.patientService.getVisitData(parameter).subscribe(res=>{
      this.createGroup(res.result);
    });
  }
  createGroup(visitJson: any) {
    const groups = visitJson.reduce((groups, game) => {
      const date = game.created_at.split('T')[0];
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(game);
      return groups;
    }, {});
    this.visit_data = Object.keys(groups).map((date) => {
      return {
        date,
        visit: groups[date]
      };
    });
    console.log(this.visit_data);
    this.loading = false;
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
}
