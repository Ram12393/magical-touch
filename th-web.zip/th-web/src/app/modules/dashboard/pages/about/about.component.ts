import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from "@ngrx/store";
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit, OnDestroy {
  public about_info:any;
  public settings: {};
  public loading: boolean = false;
  constructor(private route:Router, private patientSerive:PatientService, private store:Store<{}>) { 
    this.store.select(GetSettings)
    .subscribe(settings => {
      this.settings = settings;
    });
  }
  ngOnInit() {
    this.loading = true;
    let guid = this.route.url.split("/")[this.route.url.split("/").length-2];
    let parameter:any;
    if(this.settings["view"] == "DOCTOR") {
      parameter = {
        params: {
          filter_user_guid_in: guid
      }
    }
    } else {
      parameter = {
        params: {
          doctor_guid:guid.split("&")[1],
          filter_user_guid_in: guid.split("&")[0]
      }
    }
    }
    this.patientSerive.getPatientInfo(parameter)
  .subscribe((result) => {
    this.about_info = result[0];
    this.loading = false;
  });
  }
  ngOnDestroy() {
    
  }
}
