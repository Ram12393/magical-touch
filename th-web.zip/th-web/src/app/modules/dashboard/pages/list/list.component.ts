import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { DoctorService } from 'src/app/core/services/doctor.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  public patient_Details: any;
  public profilesRequestConfig: any;
  public guid: any;
  public loadinglist = false;
  public settings = {};
  @Input()
  set doctor_guid(message: string ) {
    this.guid = message;
    this.patientList(this.guid);
  }
  constructor(
    private patientService: PatientService,
    private doctorService: DoctorService,
    private router: Router,
    private store: Store<{}>) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
    this.resetProfilesRequestConfig();
  }
  ngOnInit() {
  }
  patientList(guid: string) {
    this.loadinglist = true;
    if (this.settings['view'] === 'DOCTOR') {
      this.patientService.getPatientList({
        params: {
          page: 1, // ++this.profilesRequestConfig.page,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true
        }
      })
        .subscribe((result) => {
          this.patient_Details = result.result;
          this.loadinglist = false;
          this.fetch_info(this.patient_Details[0].user_guid, guid);
        });
    } else {
      this.doctorService.getDoctorList({
        params: {
          doctor_guid: guid,
          page: 1, // ++this.profilesRequestConfig.page,
          page_size: this.profilesRequestConfig.page_size,
          paginate: true,

        }
      })
        .subscribe((result) => {
          this.loadinglist = false;
          this.patient_Details = result.result;
          this.fetch_info(this.patient_Details[0].user_guid, guid);
        });
    }
  }
  fetch_info(user_guid: any, guid: string) {
    let passing_guid: any;
    for (let i = 0; i < this.patient_Details.length; i++) {
      this.patient_Details[i].active = false;
      if (this.patient_Details[i].user_guid === user_guid) {
        this.patient_Details[i].active = true;
      }
    }
    if (guid === undefined) {
      passing_guid = user_guid;
    } else {
      passing_guid = user_guid + '&' + guid;
    }
    this.router.navigate(['patients', passing_guid]);
  }
  resetProfilesRequestConfig() {
    this.profilesRequestConfig = {
      page: 0,
      page_size: 20
    };
  }
}
