import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { PatientService } from 'src/app/core/services/patient.service';
import { Store } from '@ngrx/store';
import { GetSettings } from 'src/app/core/store/selectors/settings.selector';
import { filter } from 'rxjs/internal/operators';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit, OnDestroy {
  public info: any;
  public guid: string;
  public showModal = false;
  public settings: {};
  public loading = false;
  public isDisconnect: boolean;
  constructor(
    private router: Router,
    private patientService: PatientService,
    private activateroute: ActivatedRoute,
    private store: Store<{}>) {
    this.store.select(GetSettings)
      .subscribe(settings => {
        this.settings = settings;
      });
  }
  ngOnInit() {
    this.activateroute.params.subscribe(routeParams => {
      this.getDetails(routeParams.user_guid);
      this.guid = routeParams.user_guid;
    });
    this.isDisconnect = true;
    // this.router.events.pipe(
    //   filter(event => event instanceof NavigationEnd)  
    // ).subscribe((event: NavigationEnd) => {

    // });
  }
  getDetails(guid) {
    this.loading = true;
    let parameter: any;
    if (this.settings['view'] === 'DOCTOR') {
      parameter = {
        params: {
          filter_user_guid_in: guid
        }
      };
    } else {
      parameter = {
        params: {
          doctor_guid: guid.split('&')[1],
          filter_user_guid_in: guid.split('&')[0]
        }
      };
    }
    this.patientService.getPatientInfo(parameter)
      .subscribe((result) => {
        this.info = result[0];
        this.loading = false;
        this.router.navigate(['patients', guid, 'about']);
      });
  }
  disconnect() {
    let parameter: any;
    if (this.settings['view'] === 'DOCTOR') {
      parameter = {
        params: {
          user_guid: this.guid
        }
      };
    } else {
      parameter = {
        params: {
          doctor_guid: this.guid.split('&')[1],
          user_guid: this.guid.split('&')[0]
        }
      };
    }
    this.patientService.disconnet_patient(parameter)
      .subscribe((result) => {
        if (result.success) {
          this.showModal = false;
        }
      });
  }
  navigate(el: string) {
    if (el == 'about') {
      this.isDisconnect = true;
      return;
    }
    this.isDisconnect = false;
  }

  ngOnDestroy() {
  }
}
