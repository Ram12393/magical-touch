import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InfoComponent } from './pages/info/info.component';
import { AboutComponent } from './pages/about/about.component';
import { VitalsComponent } from './pages/vitals/vitals.component';
import { DocumentComponent } from './pages/document/document.component';
import { VisitsComponent } from './pages/visits/visits.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import {AuthGuardService} from '../../core/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    canLoad: [AuthGuardService],
    children : [
      {
        path: ':user_guid',
        component: InfoComponent,
        children: [
          {
            path: 'about',
            component: AboutComponent
          },
          {
            path: 'document',
            component: DocumentComponent
          },
          {
            path: 'vitals',
            component: VitalsComponent
          },
          {
            path: 'visits',
            component: VisitsComponent
          },
          {
            path: 'orders',
            component: OrdersComponent
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
