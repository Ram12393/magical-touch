import { SessionReducer } from './core/store/reducers/session.reducer';
import { SettingsReducer } from './core/store/reducers/settings.reducer';

export const AppState = {
    session: SessionReducer,
    settings: SettingsReducer,
};