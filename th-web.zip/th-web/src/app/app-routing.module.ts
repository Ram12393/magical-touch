import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'patients',
    loadChildren : './modules/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'monitoring',
    loadChildren : './modules/monitoring/monitoring.module#MonitoringModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
