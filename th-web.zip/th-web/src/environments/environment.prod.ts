export const environment = {
  production: true,
  servicesEndpoint: 'https://services.telehealer.com/',
  apiEndpoint: 'https://api.dev.telehealer.com/api/',
  accountEndpoint: 'https://api.dev.telehealer.com/',
  perPage: 20
};
