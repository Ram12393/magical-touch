export const environment = {
    production: false,
    servicesEndpoint: "http://localhost:4200/services/",
    apiEndpoint: "http://localhost:4200/api/",
    accountEndpoint: "http://localhost:4200/account/",
    perPage: 20
};
